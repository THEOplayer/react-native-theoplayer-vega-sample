
# Project Title

A brief description of what this project does and who it's for

## Installation Instructions

### Download Dependencies

#### a. LogixAdsManager
-  To download the LogixAdsManager visit here: [https://logituit.com/logixads-manager/](https://logituit.com/logixads-manager/)
-  Once downloaded place the tarball file i.e. 'logituit-logix-ads-manager-0.2.0.tgz' in the `{root}/lib` directory.

###  Install Dependencies

To install the downloaded dependencies, use the following commands:

**WebView :**

```bash
npm install @amazon-devices/webview@^3.3.0
```

**LogixAdsManager :**

```bash
npm install file:./lib/logituit-logix-ads-manager-0.2.0.tgz
```

## Importing the SDK

### Manifest

Add below to the app's manifest `{App_dir}/manifest.toml`

```toml
# Web renderer service for rendering web content
[[wants.service]]
id = "com.amazon.webview.renderer_service"

# If the app needs video playback
[[wants.service]]
id = "com.amazon.media.server"
[[wants.service]]
id = "com.amazon.mediametrics.service"

# If the app needs audio playback
[[wants.service]]
id = "com.amazon.audio.stream"
[[wants.service]]
id = "com.amazon.audio.control"

[[wants.service]]
id = "com.amazon.mediabuffer.service"
[[wants.service]]
id = "com.amazon.mediatransform.service"

# You may add other services as needed (for example, DRM)

```

## How to use

Import the required libraries: Open `screen/component.tsx` file where you want to display google IMA ads and import like below:


```typescript
// Imports 
import {
  AdErrorEventType,
  AdEvent,
  AdEventType,
  AdErrorEvent,
  AdsContainer,
  LogixIMAWrapper,
} from "@logituit/logix-ads-manager";
```

Define a ref and onManagerLoaded function :

```typescript
// In React Component 
// Creating a ref to store the instance of the SDK
const logixAdsManager = useRef<LogixIMAWrapper>(null);
const videoRef = useRef<VideoPlayer>(null);

// example code for adding player's eventListeners and destroying the SDK on unmount
useEffect(() => {
  setupPlayerEvents();
  return () => {
    removePlayerEvents();
  };
}, []);


// Sets the player's progress in the Ads Manager to make sure both are in sync.
// It is necessary to set the progress in Ads Manager for it to display midroll.
const updateDuration = () => {
  if (videoRef?.current?.currentTime && videoRef?.current?.duration) {
    logixAdsManager.current?.setProgress(
      videoRef?.current?.currentTime,
      videoRef?.current?.duration
    );
  }
};

// Notifies the Ads Manager that content playback has completed.
// This should be called when the player fires the 'ended' event.
// It is required to trigger post-roll ads and finalize the ad session.
const handleContentEnd = () => {
  logixAdsManager.current?.adsManager.contentComplete();
};
  
const setupPlayerEvents = () => {
  // Updating player's duration and currentTime to the adsManager.
  videoRef?.current?.addEventListener("timeupdate", updateDuration)
  videoRef?.current?.addEventListener("ended", handleContentEnd)
};

const removePlayerEvents = () => {
  videoRef?.current?.removeEventListener("timeupdate", updateDuration)
  videoRef?.current?.removeEventListener("ended", handleContentEnd)
};

// onManagerLoaded callback for LogixIMAWrapper
const onLoad = () => {
    //This function will be passed as prop(onManagerLoaded) to the AdsContainer
    // and will be called once the logix ads manager is loaded
    // We can write all ads related business logic in this function

    // Event listener for AD_ERROR event
    logixAdsManager.current?.adsManager.addEventListener(
        AdErrorEventType.AD_ERROR,
        (data: AdErrorEvent) => {
            console.log(
                "IMA error received",
                data.getError().getMessage(),
                data.getError().name,
            );
            // Play the content
            (global as any).gmedia?.play();
        }
    );

    

    logixAdsManager.current?.adsManager.addEventListener(
        AdEventType.CONTENT_PAUSE_REQUESTED,
        (event: AdEvent) => {
            console.log("LogixAdsManager: CONTENT_PAUSE_REQUESTED");

            // to get cue points
            logixAdsManager.current?.adsManager.getCuePoints().then((cuePoints) => {
                console.log("LogixAdsManager: cuepoints", cuePoints);
            });
            
            const ad = event.getAd();
            console.log("LogixAdsManager: AdId:", ad?.getAdId());

            // Pause the content
            (global as any).gmedia?.pause();
        }
    );

    logixAdsManager.current?.adsManager.addEventListener(
        AdEventType.CONTENT_RESUME_REQUESTED, () => {
            console.log("LogixAdsManager: CONTENT_RESUME_REQUESTED");

            // Play the content
            (global as any).gmedia?.play();
        }
    );
    //to get AdPodInfo
   logixAdsManager.current?.adsManager.addEventListener(
      AdEventType.STARTED,
      (event: AdEvent) => {
        const ad = event.getAd();
        console.log('LogixAdsManager: AdPodInfo', ad?.getAdPodInfo());
      },
    );

    logixAdsManager.current?.adsManager.addEventListener(
      AdEventType.AD_PROGRESS,
      (event: AdEvent) => {
         // to get information about the current ad progress
        const adProgressData = event.getAdData();
        console.log('LogixAdsManager: AdProgressData', adProgressData);

         // to get remaining time
        logixAdsManager.current?.adsManager.getRemainingTime().then((time) => {
          console.log('LogixAdsManager: remainingtime', time);
        });
      },
    );
    logixAdsManager.current?.adsManager.addEventListener(
        AdEventType.FIRST_QUARTILE, () => {
            console.log("LogixAdsManager: FIRST_QUARTILE");
        }
    );

    logixAdsManager.current?.adsManager.addEventListener(
      AdEventType.MIDPOINT,
      (event: AdEvent) => {
        console.log('LogixAdsManager: MIDPOINT');
        const ad = event.getAd();
        console.log('LogixAdsManager: adId', ad?.getAdId());
        console.log('LogixAdsManager: adTitle', ad?.getTitle());
      },
    );

    logixAdsManager.current?.adsManager.addEventListener(
        AdEventType.THIRD_QUARTILE, () => {
            console.log("LogixAdsManager: THIRD_QUARTILE");
        }
    );

    // example: how to remove event listeners
    const eventId = logixAdsManager.current?.adsManager.addEventListener(
        AdEventType.CONTENT_PAUSE_REQUESTED, () => {
            console.log("LogixAdsManager: CONTENT_PAUSE_REQUESTED 2");
        }
    );

    // It is just an example; the events should be unsubscribed on unmount.
    // this removes the event listener after 2 seconds
    // but we can remove the event listeners according to the business logic
    // for eg remove all event listeners when player screen is unmounted
    setTimeout(() => {
        if (eventId) {
          logixAdsManager.current?.adsManager.removeEventListener(eventId);
        }
    }, 2000);

}
..
..
..
// APP CODE

```
Render AdsContainer : *(JSX that is returned by the React Component)*


```jsx

<View>
    <View>
        {/* Player Component */}
        <VideoPlayer ref={videoRef} />

    </View>

    {/* LOGIX IMA - begins */}
  <AdsContainer
    ref={logixAdsManager}
    adTagUrl={YOUR_AD_TAG_URL}
    onManagerLoaded={onLoad}
    onError={(err) => {
      console.log("ima error", err)
    }}
  />
  {/* LOGIX IMA - ends */}
</View>

```

### updateAdsRenderingSettings : 

```typescript
import { AdsRenderingSettings } from '@logituit/logix-ads-manager/dist/interface';

const adsRenderingSettings: AdsRenderingSettings = {
  enablePreloading: true,
  uiElements: ['countdown', 'adAttribution'],
  autoAlign: true,
  bitrate: -1,
  loadVideoTimeout: -1,
  mimeTypes: [],
  playAdsAfterTime: 0,
  restoreCustomPlaybackStateOnAdBreakComplete: false,
};

const onLoad = () => {
  ...

  logixAdsManager.current?.adsManager.updateAdsRenderingSettings(adsRenderingSettings);

  ...
}
```

**AdsRenderingSettings Configuration :**

| Option                                      | Type       | Default | Description                                                                                                              |
|---------------------------------------------|------------|---------|--------------------------------------------------------------------------------------------------------------------------|
| `autoAlign`                                | `boolean`   | `true`  | Set to `false` to have fine-grained control over the positioning of non-linear ads. `true` positions the ad at the bottom center, `false` positions it at the top left corner. |
| `bitrate`                                  | `number`    | `-1`    | Maximum recommended bitrate in kbit/s. The SDK will select media with a bitrate below the specified max, or the closest bitrate if no lower bitrate media is found. `-1` means the SDK selects the bitrate automatically. |
| `enablePreloading`                         | `boolean`   |         | Enables preloading of video assets. For more information, refer to the guide on preloading media.                  |
| `loadVideoTimeout`                         | `number`    | `-1`    | Timeout in milliseconds for loading a video ad media file. If loading takes longer, ad playback is canceled, and the next ad in the pod plays if available. `-1` means the timeout is 8 seconds. |
| `mimeTypes`                                | `string[]`  |         | List of MIME types supported for linear video. The SDK will include media that matches these types and exclude others. If not specified, media is selected based on player capabilities. |
| `playAdsAfterTime`                         | `number`    |         | For VMAP and ad rules playlists, only play ad breaks scheduled after this time (in seconds). This setting strictly applies after the specified time. |
| `restoreCustomPlaybackStateOnAdBreakComplete` | `boolean`   |         | Specifies whether the SDK should restore the custom playback state after an ad break completes. Used when a custom content player is provided for ad playback. |
| `uiElements`                               | `string[]`  |         | Interface for UI elements within the ads rendering.   

### Destroying the adsManager : 

```typescript
useEffect(() => {
    return () => {
      logixAdsManager.current?.destroy();
    };
  }, []);
```

## Misc

#### Handle Throttle :

This utility function throttles the execution of a given function, ensuring it is called at most once within the specified time limit. It's useful for limiting the rate at which a function is invoked.

```typescript
export default function handleThrottle(func: Function, limit: number) {
  let inThrottle: boolean;
  return function (this: any, ...args: any[]) {
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}
```

**use case**

Throttle the updateDuration function to ensure it runs at most once every 1000 milliseconds:

```typescript
const updateDuration = () => {
  if (videoRef?.current?.currentTime && videoRef?.current?.duration) {
    logixAdsManager.current?.setProgress(
      videoRef?.current?.currentTime,
      videoRef?.current?.duration,
    );
  }
};

// Create a throttled version of updateDuration, allowing it to be called 
// at most once every 1 second (1000 milliseconds).
videoRef?.current?.addEventListener(
  'timeupdate',
  handleThrottle(updateDuration, 1000),
);
```