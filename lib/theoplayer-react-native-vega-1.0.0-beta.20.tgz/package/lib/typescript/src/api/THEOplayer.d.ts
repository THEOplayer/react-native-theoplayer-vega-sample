export { THEOplayerAdapter as THEOplayer } from '../internal/adapter/THEOplayerAdapter.vega';
//# sourceMappingURL=THEOplayer.d.ts.map