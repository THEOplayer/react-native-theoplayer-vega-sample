export * from './view/barrel';
//# sourceMappingURL=barrel.d.ts.map