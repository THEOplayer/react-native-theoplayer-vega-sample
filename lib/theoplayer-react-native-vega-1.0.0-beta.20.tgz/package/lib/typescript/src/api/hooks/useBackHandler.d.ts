interface BackHandlerProps {
    onBack?: () => void;
}
export declare const useBackHandler: ({ onBack }: BackHandlerProps) => void;
export {};
//# sourceMappingURL=useBackHandler.d.ts.map