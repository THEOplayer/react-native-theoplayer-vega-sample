import { THEOplayer } from 'react-native-theoplayer';
export declare function useBuffered(player: THEOplayer | undefined): string;
//# sourceMappingURL=useBuffered.d.ts.map