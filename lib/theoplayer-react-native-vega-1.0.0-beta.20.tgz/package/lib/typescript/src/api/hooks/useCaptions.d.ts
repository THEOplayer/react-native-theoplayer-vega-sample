import { THEOplayer } from 'react-native-theoplayer';
import { VideoPlayer } from '@amazon-devices/react-native-w3cmedia';
export declare const useCaptions: (player: THEOplayer | undefined, videoPlayer: VideoPlayer | undefined) => void;
//# sourceMappingURL=useCaptions.d.ts.map