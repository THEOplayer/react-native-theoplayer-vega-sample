import { THEOplayer } from 'react-native-theoplayer';
export declare function useCurrentTime(player: THEOplayer | undefined): number;
//# sourceMappingURL=useCurrentTime.d.ts.map