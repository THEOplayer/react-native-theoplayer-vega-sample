import { PlayerEventMap, THEOplayer } from 'react-native-theoplayer';
export declare function usePlayerEvent<K extends keyof PlayerEventMap>(player: THEOplayer | undefined, event: K | K[], onEvent: (event: PlayerEventMap[K]) => void): void;
//# sourceMappingURL=usePlayerEvent.d.ts.map