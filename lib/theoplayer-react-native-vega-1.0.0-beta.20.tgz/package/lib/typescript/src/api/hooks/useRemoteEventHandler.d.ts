import { THEOplayer } from 'react-native-theoplayer';
export interface RemoteEventHandlerConfig {
    skipForward: number;
    skipBackward: number;
}
export declare const defaultRemoteEventHandlerConfig: {
    skipForward: number;
    skipBackward: number;
};
export declare const useRemoteEventHandler: (player: THEOplayer | undefined, config?: RemoteEventHandlerConfig) => void;
//# sourceMappingURL=useRemoteEventHandler.d.ts.map