import { TimeRange } from 'react-native-theoplayer';
export declare function logTimeRanges(ranges: TimeRange[] | undefined): string;
//# sourceMappingURL=log.d.ts.map