import React from 'react';
import { THEOplayerViewProps } from 'react-native-theoplayer';
import { THEOplayer } from '../THEOplayer';
import { VegaPlayerConfiguration } from '../player/VegaPlayerConfiguration';
export interface VegaTHEOplayerViewProps extends THEOplayerViewProps {
    /**
     * Whether to reset the player when unmounting the THEOplayerView.
     *
     * @default true, unless a player was provided via props.
     */
    resetPlayerOnUnmount?: boolean;
    /**
     * Optionally provide a headless player that is attached to the THEOplayerView component.
     */
    player?: THEOplayer;
    /**
     * Player configuration.
     */
    config?: VegaPlayerConfiguration;
}
export declare function THEOplayerView(props: React.PropsWithChildren<VegaTHEOplayerViewProps>): React.JSX.Element;
//# sourceMappingURL=THEOplayerView.vega.d.ts.map