import { TextTrack, THEOplayer } from 'react-native-theoplayer';
export interface TextTrackState {
    textTracks: TextTrack[];
    selectedTextTrack: number | undefined;
}
export declare class DefaultTextTrackState implements TextTrackState {
    private _player;
    private _textTracks;
    private _selectedTextTrack;
    constructor(_player: THEOplayer);
    destroy(): void;
    get textTracks(): TextTrack[];
    set textTracks(tracks: TextTrack[]);
    private onLoadedMetadata;
    private onTextTrack;
    private onTextTrackList;
    get selectedTextTrack(): number | undefined;
    set selectedTextTrack(trackUid: number | undefined);
    private hasValidSource;
}
//# sourceMappingURL=DefaultTextTrackState.d.ts.map