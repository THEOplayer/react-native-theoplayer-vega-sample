import { VideoPlayer } from '@amazon-devices/react-native-w3cmedia';
import { IMediaControlHandlerAsync } from '@amazon-devices/kepler-media-controls';
import { ABRConfiguration, AdsAPI, AspectRatio, BackgroundAudioConfiguration, CastAPI, Event, EventBroadcastAPI, MediaTrack, NativeHandleType, PiPConfiguration, PlayerVersion, PreloadType, PresentationMode, RenderingTarget, SourceDescription, TextTrack, TextTrackStyle, TheoAdsAPI, TheoLiveAPI, THEOplayer as ReactNativeTHEOplayer, TimeRange, PlayerEventMap } from 'react-native-theoplayer';
import { IComponentInstance } from '@amazon-devices/react-native-kepler';
import { DefaultEventDispatcher } from './event/DefaultEventDispatcher';
import { VegaPlayerConfiguration } from '../../api/player/VegaPlayerConfiguration';
import { LogixIMAWrapper } from '@logituit/logix-ads-manager';
export declare enum VegaPlayerEventType {
    /**
     * Dispatched when the video element has changed.
     */
    SURFACE_CHANGED = "surfacechanged"
}
export interface VegaPlayerEventMap extends PlayerEventMap {
    [VegaPlayerEventType.SURFACE_CHANGED]: Event<VegaPlayerEventType.SURFACE_CHANGED>;
}
/**
 * THEOplayerAdapter implements the THEOplayer interface from @theoplayer/react-native.
 *
 * A `nativeHandle` property is provided to expose a web-like player interface for attaching native web connectors.
 */
export declare class THEOplayerAdapter extends DefaultEventDispatcher<VegaPlayerEventMap> implements ReactNativeTHEOplayer {
    private _player;
    private readonly _cast;
    private readonly _broadcast;
    private _adsAdapter;
    private _theoAdsAdapter;
    private _theoLiveAdapter;
    private readonly _configuration;
    private _video;
    private _resetPromise;
    private readonly _textTrackListeners;
    private readonly _mediaTrackListeners;
    private _targetVideoQuality;
    private _surfaceHandle;
    private _captionViewHandle;
    private _mediaControlComponent;
    private _mediaControlHandler;
    private readonly _textTrackState;
    renderingTarget?: RenderingTarget | undefined;
    static create(configuration?: VegaPlayerConfiguration | undefined): Promise<THEOplayerAdapter>;
    constructor(video: VideoPlayer, configuration?: VegaPlayerConfiguration | undefined);
    setSurfaceHandle(handle: string | undefined): void;
    setCaptionViewHandle(handle: string | undefined): void;
    clearSurfaceHandle(handle: string): void;
    clearCaptionViewHandle(handle: string): void;
    setMediaControlFocus(mediaControlComponent?: IComponentInstance, mediaControlHandler?: IMediaControlHandlerAsync): Promise<void>;
    setAdsManager(adsWrapper: LogixIMAWrapper | null): void;
    private initPlayer;
    destroy(): Promise<void>;
    private resetPlayer;
    get nativeHandle(): NativeHandleType;
    get version(): PlayerVersion;
    get aspectRatio(): AspectRatio;
    get keepScreenOn(): boolean;
    get pipConfiguration(): PiPConfiguration;
    get backgroundAudioConfiguration(): BackgroundAudioConfiguration;
    get source(): SourceDescription | undefined;
    set source(source: SourceDescription | undefined);
    get presentationMode(): PresentationMode;
    get textTrackStyle(): TextTrackStyle;
    get broadcast(): EventBroadcastAPI;
    get ads(): AdsAPI;
    get theoads(): TheoAdsAPI;
    get theoLive(): TheoLiveAPI;
    get theolive(): TheoLiveAPI;
    get cast(): CastAPI;
    get buffered(): TimeRange[];
    get currentTime(): number;
    set currentTime(time: number);
    get currentProgramDateTime(): number | undefined;
    get duration(): number;
    get muted(): boolean;
    set muted(value: boolean);
    get paused(): boolean;
    get playbackRate(): number;
    set playbackRate(value: number);
    get preload(): PreloadType;
    set preload(value: PreloadType);
    get seekable(): TimeRange[];
    get seeking(): boolean;
    get volume(): number;
    set volume(value: number);
    get audioTracks(): MediaTrack[];
    get videoTracks(): MediaTrack[];
    get textTracks(): TextTrack[];
    play(): void;
    get width(): number;
    get height(): number;
    get videoWidth(): number | undefined;
    get videoHeight(): number | undefined;
    get autoplay(): boolean;
    set autoplay(value: boolean);
    pause(): void;
    get abr(): ABRConfiguration | undefined;
    get selectedTextTrack(): number | undefined;
    set selectedTextTrack(uid: number | undefined);
    get selectedAudioTrack(): number | undefined;
    set selectedAudioTrack(selectedAudioTrack: number | undefined);
    get selectedVideoTrack(): number | undefined;
    set selectedVideoTrack(selectedVideoTrack: number | undefined);
    get targetVideoQuality(): number | number[] | undefined;
    set targetVideoQuality(targetVideoQuality: number | number[] | undefined);
    private forwardCoreTextTrackListEvent_;
    private forwardCoreTextTrackEvent_;
    private forwardCoreAudioTrackListEvent_;
    private forwardCoreVideoTrackListEvent_;
    private forwardCoreMediaTrackListEvent_;
    private forwardCoreMediaTrackEvent_;
    private forwardCorePlayerEvent_;
}
//# sourceMappingURL=THEOplayerAdapter.vega.d.ts.map