import { AdEvent as LogixAdEvent } from '@logituit/logix-ads-manager';
import { Ad, AdBreak, AdSource } from 'react-native-theoplayer';
export declare const INVALID_ADBREAK: AdBreak;
export declare const INVALID_AD: Ad;
export declare function fromLogixAd(event: LogixAdEvent, currentAdBreak?: AdBreak | undefined): Ad;
export declare function fillAdBreakWithLogixPodInfo(adBreak: AdBreak | undefined, event: LogixAdEvent): AdBreak;
export declare function adBreakFromCuePoints(cuePoints: number[]): AdBreak | undefined;
export declare const extractAdTagUrl: (sources?: string | AdSource) => string | undefined;
//# sourceMappingURL=LogixAdsAdapter.d.ts.map