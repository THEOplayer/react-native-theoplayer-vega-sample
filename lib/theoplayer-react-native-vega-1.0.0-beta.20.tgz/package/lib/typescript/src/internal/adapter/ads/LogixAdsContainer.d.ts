import React from 'react';
import { THEOplayer } from '../../../api/THEOplayer';
export interface AdsManagerProps {
    player: THEOplayer | undefined;
}
export declare const LogixAdsContainer: (props: AdsManagerProps) => React.JSX.Element | null;
//# sourceMappingURL=LogixAdsContainer.d.ts.map