import { EventBroadcastAPI } from 'react-native-theoplayer';
import type { Event } from 'react-native-theoplayer';
export declare class DummyEventBroadcastAPI implements EventBroadcastAPI {
    broadcastEvent(_event: Event): void;
}
//# sourceMappingURL=EventBroadcastAPI.d.ts.map