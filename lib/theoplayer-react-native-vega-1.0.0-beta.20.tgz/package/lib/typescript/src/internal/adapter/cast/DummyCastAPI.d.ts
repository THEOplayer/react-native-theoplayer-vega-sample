import { CastAPI } from 'react-native-theoplayer';
export declare class DummyCastAPI implements CastAPI {
    casting: boolean;
}
//# sourceMappingURL=DummyCastAPI.d.ts.map