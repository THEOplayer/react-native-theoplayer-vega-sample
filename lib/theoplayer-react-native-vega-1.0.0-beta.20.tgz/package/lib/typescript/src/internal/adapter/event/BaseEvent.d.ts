import type { Event } from '@theoplayer/react-native-vega';
export declare class BaseEvent<TType extends string = string> implements Event<TType> {
    readonly type: TType;
    readonly date: Date;
    constructor(type: TType, date?: Date);
}
//# sourceMappingURL=BaseEvent.d.ts.map