import type { EventDispatcher, EventListener, EventMap, StringKeyOf } from 'react-native-theoplayer';
export declare class DefaultEventDispatcher<TMap extends EventMap<StringKeyOf<TMap>>> implements EventDispatcher<TMap> {
    readonly _eventListeners: Map<StringKeyOf<TMap>, EventListener<TMap[StringKeyOf<TMap>]>[]>;
    addEventListener<K extends StringKeyOf<TMap>>(type: K | readonly K[], listener: EventListener<TMap[K]>): void;
    private addSingleEventListener;
    clearEventListeners(): void;
    dispatchEvent: <K extends StringKeyOf<TMap>>(event: TMap[K]) => void;
    removeEventListener<K extends StringKeyOf<TMap>>(type: K | readonly K[], listener: EventListener<TMap[K]>): void;
    private removeSingleEventListener;
}
//# sourceMappingURL=DefaultEventDispatcher.d.ts.map