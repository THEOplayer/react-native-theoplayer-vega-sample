import { BaseEvent } from './BaseEvent';
import { Ad, AdBreak, AdEvent, AdEventType, AirplayStateChangeEvent, CastEventType, CastState, ChromecastChangeEvent, ChromecastError, ChromecastErrorEvent, DurationChangeEvent, ErrorEvent, Interstitial, LoadedMetadataEvent, MediaTrack, MediaTrackEvent, MediaTrackEventType, MediaTrackListEvent, MediaTrackType, PlayerError, PlayerEventType, PresentationMode, PresentationModeChangeContext, PresentationModeChangeEvent, ProgressEvent, Quality, RateChangeEvent, ReadyStateChangeEvent, ResizeEvent, SeekedEvent, SeekingEvent, SegmentNotFoundEvent, TextTrack, TextTrackCue, TextTrackEvent, TextTrackEventType, TextTrackListEvent, TheoAdsEvent, TheoAdsErrorEvent, TheoAdsEventType, TheoLiveEvent, TheoLiveDistributionEvent, TheoLiveEventType, TimeRange, TimeUpdateEvent, TrackListEventType, VolumeChangeEvent, TheoLiveEndpoint, TheoLiveEndpointLoadedEvent, TheoLiveIntentToFallbackEvent, DimensionChangeEvent, VideoResizeEvent } from '@theoplayer/react-native-vega';
export declare class DefaultLoadedMetadataEvent extends BaseEvent<PlayerEventType.LOADED_METADATA> implements LoadedMetadataEvent {
    textTracks: TextTrack[];
    audioTracks: MediaTrack[];
    videoTracks: MediaTrack[];
    duration: number;
    selectedTextTrack: number | undefined;
    selectedVideoTrack: number | undefined;
    selectedAudioTrack: number | undefined;
    constructor(textTracks: TextTrack[], audioTracks: MediaTrack[], videoTracks: MediaTrack[], duration: number, selectedTextTrack: number | undefined, selectedVideoTrack: number | undefined, selectedAudioTrack: number | undefined);
}
export declare class DefaultReadyStateChangeEvent extends BaseEvent<PlayerEventType.READYSTATE_CHANGE> implements ReadyStateChangeEvent {
    readyState: number;
    constructor(readyState: number);
}
export declare class DefaultPresentationModeChangeEvent extends BaseEvent<PlayerEventType.PRESENTATIONMODE_CHANGE> implements PresentationModeChangeEvent {
    presentationMode: PresentationMode;
    previousPresentationMode: PresentationMode;
    context?: PresentationModeChangeContext | undefined;
    constructor(presentationMode: PresentationMode, previousPresentationMode: PresentationMode, context?: PresentationModeChangeContext | undefined);
}
export declare class DefaultVolumeChangeEvent extends BaseEvent<PlayerEventType.VOLUME_CHANGE> implements VolumeChangeEvent {
    volume: number;
    muted: boolean;
    constructor(volume: number, muted: boolean);
}
/**
 * @deprecated Use {@link DefaultDimensionChangeEvent} instead. This event is set for removal in version 11.
 */
export declare class DefaultResizeEvent extends BaseEvent<PlayerEventType.RESIZE> implements ResizeEvent {
    width: number;
    height: number;
    constructor(width: number, height: number);
}
export declare class DefaultDimensionChangeEvent extends BaseEvent<PlayerEventType.DIMENSION_CHANGE> implements DimensionChangeEvent {
    width: number;
    height: number;
    constructor(width: number, height: number);
}
export declare class DefaultVideoResizeEvent extends BaseEvent<PlayerEventType.VIDEO_RESIZE> implements VideoResizeEvent {
    videoWidth: number;
    videoHeight: number;
    constructor(videoWidth: number, videoHeight: number);
}
export declare class DefaultErrorEvent extends BaseEvent<PlayerEventType.ERROR> implements ErrorEvent {
    error: PlayerError;
    constructor(error: PlayerError);
}
export declare class DefaultProgressEvent extends BaseEvent<PlayerEventType.PROGRESS> implements ProgressEvent {
    seekable: TimeRange[];
    buffered: TimeRange[];
    constructor(seekable: TimeRange[], buffered: TimeRange[]);
}
export declare class DefaultTimeupdateEvent extends BaseEvent<PlayerEventType.TIME_UPDATE> implements TimeUpdateEvent {
    currentTime: number;
    currentProgramDateTime?: number | undefined;
    constructor(currentTime: number, currentProgramDateTime?: number | undefined);
}
export declare class DefaultDurationChangeEvent extends BaseEvent<PlayerEventType.DURATION_CHANGE> implements DurationChangeEvent {
    duration: number;
    constructor(duration: number);
}
export declare class DefaultRateChangeEvent extends BaseEvent<PlayerEventType.RATE_CHANGE> implements RateChangeEvent {
    playbackRate: number;
    constructor(playbackRate: number);
}
export declare class DefaultSegmentNotFoundEvent extends BaseEvent<PlayerEventType.SEGMENT_NOT_FOUND> implements SegmentNotFoundEvent {
    readonly segmentStartTime: number;
    error: string;
    retryCount: number;
    constructor(segmentStartTime: number, error: string, retryCount: number);
}
export declare class DefaultSeekingEvent extends BaseEvent<PlayerEventType.SEEKING> implements SeekingEvent {
    readonly currentTime: number;
    constructor(currentTime: number);
}
export declare class DefaultSeekedEvent extends BaseEvent<PlayerEventType.SEEKED> implements SeekedEvent {
    readonly currentTime: number;
    constructor(currentTime: number);
}
export declare class DefaultTextTrackListEvent extends BaseEvent<PlayerEventType.TEXT_TRACK_LIST> implements TextTrackListEvent {
    subType: TrackListEventType;
    track: TextTrack;
    constructor(subType: TrackListEventType, track: TextTrack);
}
export declare class DefaultTextTrackEvent extends BaseEvent<PlayerEventType.TEXT_TRACK> implements TextTrackEvent {
    subType: TextTrackEventType;
    trackUid: number;
    cue: TextTrackCue;
    constructor(subType: TextTrackEventType, trackUid: number, cue: TextTrackCue);
}
export declare class DefaultMediaTrackListEvent extends BaseEvent<PlayerEventType.MEDIA_TRACK_LIST> implements MediaTrackListEvent {
    subType: TrackListEventType;
    trackType: MediaTrackType;
    track: MediaTrack;
    constructor(subType: TrackListEventType, trackType: MediaTrackType, track: MediaTrack);
}
export declare class DefaultMediaTrackEvent extends BaseEvent<PlayerEventType.MEDIA_TRACK> implements MediaTrackEvent {
    subType: MediaTrackEventType;
    trackType: MediaTrackType;
    trackUid: number;
    qualities?: (Quality | Quality[]) | undefined;
    constructor(subType: MediaTrackEventType, trackType: MediaTrackType, trackUid: number, qualities?: (Quality | Quality[]) | undefined);
}
export declare class DefaultAdEvent extends BaseEvent<PlayerEventType.AD_EVENT> implements AdEvent {
    subType: AdEventType;
    ad: Ad | AdBreak;
    constructor(subType: AdEventType, ad: Ad | AdBreak);
}
export declare class DefaultTheoAdsEvent extends BaseEvent<PlayerEventType.THEOADS_EVENT> implements TheoAdsEvent {
    subType: TheoAdsEventType;
    interstitial: Interstitial;
    constructor(subType: TheoAdsEventType, interstitial: Interstitial);
}
export declare class DefaultTheoAdsErrorEvent extends BaseEvent<PlayerEventType.THEOADS_EVENT> implements TheoAdsErrorEvent {
    subType: TheoAdsEventType;
    interstitial: Interstitial;
    message: string | undefined;
    constructor(subType: TheoAdsEventType, interstitial: Interstitial, message: string | undefined);
}
export declare class DefaultTheoLiveEvent extends BaseEvent<PlayerEventType.THEOLIVE_EVENT> implements TheoLiveEvent {
    subType: TheoLiveEventType;
    constructor(subType: TheoLiveEventType);
}
export declare class DefaultTheoLiveDistributionEvent extends BaseEvent<PlayerEventType.THEOLIVE_EVENT> implements TheoLiveDistributionEvent {
    subType: TheoLiveEventType;
    distributionId: string;
    constructor(subType: TheoLiveEventType, distributionId: string);
}
export declare class DefaultTheoLiveEndpointLoadedEvent extends BaseEvent<PlayerEventType.THEOLIVE_EVENT> implements TheoLiveEndpointLoadedEvent {
    subType: TheoLiveEventType;
    endpoint?: TheoLiveEndpoint | undefined;
    constructor(subType: TheoLiveEventType, endpoint?: TheoLiveEndpoint | undefined);
}
export declare class DefaultTheoLiveIntentToFallbackEvent extends BaseEvent<PlayerEventType.THEOLIVE_EVENT> implements TheoLiveIntentToFallbackEvent {
    subType: TheoLiveEventType;
    reason?: PlayerError | undefined;
    constructor(subType: TheoLiveEventType, reason?: PlayerError | undefined);
}
export declare class DefaultChromecastChangeEvent extends BaseEvent<PlayerEventType.CAST_EVENT> implements ChromecastChangeEvent {
    state: CastState;
    readonly subType: CastEventType.CHROMECAST_STATE_CHANGE;
    constructor(state: CastState);
}
export declare class DefaultAirplayStateChangeEvent extends BaseEvent<PlayerEventType.CAST_EVENT> implements AirplayStateChangeEvent {
    state: CastState;
    readonly subType: CastEventType.AIRPLAY_STATE_CHANGE;
    constructor(state: CastState);
}
export declare class DefaultChromecastErrorEvent extends BaseEvent<PlayerEventType.CAST_EVENT> implements ChromecastErrorEvent {
    error: ChromecastError;
    readonly subType: CastEventType.CHROMECAST_ERROR;
    constructor(error: ChromecastError);
}
//# sourceMappingURL=PlayerEvents.d.ts.map