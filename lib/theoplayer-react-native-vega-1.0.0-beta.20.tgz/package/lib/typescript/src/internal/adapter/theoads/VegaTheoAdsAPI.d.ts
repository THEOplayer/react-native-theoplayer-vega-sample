import { TheoAdsAPI, Interstitial } from 'react-native-theoplayer';
import { VegaPlayer } from '@theoplayer/vega';
export declare class VegaTheoAdsAPI implements TheoAdsAPI {
    private readonly player;
    private readonly _player;
    constructor(player: VegaPlayer);
    get currentInterstitials(): Promise<readonly Interstitial[]>;
    get scheduledInterstitials(): Promise<readonly Interstitial[]>;
    replaceAdTagParameters(adTagParameters?: Record<string, string>): void;
}
//# sourceMappingURL=VegaTheoAdsAPI.d.ts.map