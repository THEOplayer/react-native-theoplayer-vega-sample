import { HespLatencies, TheoLiveAPI } from 'react-native-theoplayer';
import { VegaPlayer } from '@theoplayer/vega';
export declare class VegaTheoLiveAPI implements TheoLiveAPI {
    private readonly _player;
    constructor(_player: VegaPlayer);
    /**
     * The latency measured for the playing THEOlive channel
     */
    get currentLatency(): Promise<number>;
    /**
     * A set of latency metrics, measured at different parts of the HESP pipeline.
     */
    get latencies(): Promise<HespLatencies>;
    /**
     * The authentication token used when requesting THEOlive manifests or segments.
     */
    get authToken(): undefined;
}
//# sourceMappingURL=VegaTheoLiveAPI.d.ts.map