export * from './captions/barrel';
//# sourceMappingURL=barrel.d.ts.map