import React from 'react';
import { StyleProp, TextStyle } from 'react-native';
import { TextTrackCue } from 'react-native-theoplayer';
interface Cea608ContentWindow {
    characters_: string;
    style_: {
        fontColor_: string;
        fontFamily_: string;
        fontSize_: string;
        backgroundColor_: string;
        windowColor_: string;
        edgeStyle_: string;
    };
    topLeft_: {
        row_: number;
        column_: number;
    };
}
interface Cea608RowProps {
    contentWindow: Cea608ContentWindow;
    captionStyle?: StyleProp<TextStyle>;
}
export declare const Cea608Row: (props: Cea608RowProps) => React.JSX.Element;
export interface Cea608ViewProps {
    cue: TextTrackCue;
    captionStyle?: StyleProp<TextStyle>;
}
export declare const Cea608View: (props: Cea608ViewProps) => React.JSX.Element;
export {};
//# sourceMappingURL=Cea60xView.d.ts.map