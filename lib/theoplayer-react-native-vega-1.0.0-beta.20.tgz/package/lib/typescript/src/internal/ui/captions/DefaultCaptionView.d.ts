import React from 'react';
import { StyleProp, TextStyle } from 'react-native';
import { TextTrackCue } from 'react-native-theoplayer';
export interface DefaultCaptionViewProps {
    cue: TextTrackCue;
    captionStyle?: StyleProp<TextStyle>;
}
export declare const DefaultCaptionView: (props: DefaultCaptionViewProps) => React.JSX.Element | null;
//# sourceMappingURL=DefaultCaptionView.d.ts.map