import { type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
import React from 'react';
import { THEOplayer } from 'react-native-theoplayer';
export interface PlayerCaptionsViewProps {
    player: THEOplayer | undefined;
    style?: StyleProp<ViewStyle>;
    captionStyle?: StyleProp<TextStyle>;
}
export declare const THEOplayerCaptionsView: ({ style, captionStyle, player }: PlayerCaptionsViewProps) => React.JSX.Element;
//# sourceMappingURL=THEOplayerCaptionsView.d.ts.map