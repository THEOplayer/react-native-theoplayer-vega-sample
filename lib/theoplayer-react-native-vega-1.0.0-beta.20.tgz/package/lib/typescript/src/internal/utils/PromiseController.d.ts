export declare class PromiseController<T> {
    readonly promise_: Promise<T>;
    private _resolve;
    private _reject;
    constructor();
    resolve_(result: T): void;
    reject_(reason: any): void;
    abort_(): void;
    follow_(result: PromiseLike<T>): void;
    private destroy_;
}
//# sourceMappingURL=PromiseController.d.ts.map