import type { MediaTrack as CoreMediaTrack, MediaTrackList as CoreMediaTrackList, Quality as CoreQuality, TextTrack as CoreTextTrack, TextTrackCue as CoreTextTrackCue, TextTracksList as CoreTextTrackList } from '@theoplayer/vega';
import type { MediaTrack, TextTrack, TextTrackCue, DateRangeCue } from 'react-native-theoplayer';
export declare function decodeNanInf(v: number | undefined): number | undefined;
export declare function isDateRangeCue(cue: TextTrackCue): cue is DateRangeCue;
export declare function fromCoreCue(cue: CoreTextTrackCue): TextTrackCue;
export declare function fromCoreTextTrackList(tracks: CoreTextTrackList): TextTrack[];
export declare function fromCoreTextTrack(track: CoreTextTrack): TextTrack;
export declare function fromNativeMediaTrackList(tracks: CoreMediaTrackList): MediaTrack[];
export declare function fromCoreMediaTrack(track: CoreMediaTrack): MediaTrack;
export declare function findCoreQualityByUid(mediaTrack: CoreMediaTrack, uid: number | undefined): CoreQuality | undefined;
export declare function findCoreQualitiesByUid(mediaTrack: CoreMediaTrack | undefined, uid: number | number[] | undefined): CoreQuality[] | undefined;
//# sourceMappingURL=TrackUtils.d.ts.map