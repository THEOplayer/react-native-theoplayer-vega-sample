export declare function arrayRemoveElement<T>(array: T[], element: T): boolean;
export declare function arrayRemoveAt<T>(array: T[], index: number): void;
//# sourceMappingURL=arrayUtil.d.ts.map