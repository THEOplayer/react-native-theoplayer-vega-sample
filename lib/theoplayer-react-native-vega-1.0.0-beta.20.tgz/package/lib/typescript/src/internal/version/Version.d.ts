import type { SdkVersions } from 'react-native-theoplayer';
export declare const sdkVersions: () => Promise<SdkVersions>;
//# sourceMappingURL=Version.d.ts.map