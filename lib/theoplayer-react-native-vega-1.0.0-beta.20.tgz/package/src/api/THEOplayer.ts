export { THEOplayerAdapter as THEOplayer } from '../internal/adapter/THEOplayerAdapter.vega';
