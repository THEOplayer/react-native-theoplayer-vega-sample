import { useEffect } from 'react';
import { BackHandler, Platform } from 'react-native';

interface BackHandlerProps {
    onBack?: () => void;
}

export const useBackHandler = ({ onBack }: BackHandlerProps) => {
    useEffect(() => {
        const navigateBack = (): boolean | null | undefined => {
            onBack?.();
            return null;
        };
        if (Platform.isTV) {
            BackHandler.addEventListener('hardwareBackPress', navigateBack);
        }
        return () => {
            if (Platform.isTV) {
                BackHandler.removeEventListener('hardwareBackPress', navigateBack);
            }
        };
    }, []);
};
