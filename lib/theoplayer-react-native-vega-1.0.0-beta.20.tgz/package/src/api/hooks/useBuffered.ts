import { useState } from 'react';
import { PlayerEventType, THEOplayer } from 'react-native-theoplayer';
import { logTimeRanges } from '../utils/log';
import { usePlayerEvent } from './usePlayerEvent';

export function useBuffered(player: THEOplayer | undefined): string {
    const [buffered, setBuffered] = useState<string>(logTimeRanges(undefined));
    usePlayerEvent(player, PlayerEventType.PROGRESS, () => {
        setBuffered(logTimeRanges(player?.buffered));
    });
    return buffered;
}
