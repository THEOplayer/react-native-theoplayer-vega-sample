import { THEOplayer, TextTrack, PlayerEventType, TextTrackListEvent } from 'react-native-theoplayer';
import { VideoPlayer } from '@amazon-devices/react-native-w3cmedia';
import { usePlayerEvent } from './usePlayerEvent';

export const useCaptions = (player: THEOplayer | undefined, videoPlayer: VideoPlayer | undefined) => {
    usePlayerEvent(player, PlayerEventType.TEXT_TRACK_LIST, (event) => {
        const { track } = event as TextTrackListEvent;
        if ((track as TextTrack).src) {
            const vegaTrack = videoPlayer?.addTextTrack(
                'subtitles',
                track?.label,
                track?.language,
                (track as TextTrack).src,
                'application/x-subtitle-vtt'
            );
            //  By default, always enable the track for now.
            if (vegaTrack) {
                vegaTrack.mode = 'showing';
            }
        }
    });
};
