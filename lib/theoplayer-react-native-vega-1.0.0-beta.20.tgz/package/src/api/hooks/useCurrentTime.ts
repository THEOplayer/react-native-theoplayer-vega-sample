import { useState } from 'react';
import { PlayerEventType, THEOplayer, TimeUpdateEvent } from 'react-native-theoplayer';
import { usePlayerEvent } from './usePlayerEvent';

export function useCurrentTime(player: THEOplayer | undefined): number {
    const [currentTime, setCurrentTime] = useState<number>(NaN);
    usePlayerEvent(player, PlayerEventType.TIME_UPDATE, (event: TimeUpdateEvent) => {
        setCurrentTime(event.currentTime);
    });
    return currentTime;
}
