import { HWEvent, useTVEventHandler } from '@amazon-devices/react-native-kepler';
import { THEOplayer } from 'react-native-theoplayer';

export interface RemoteEventHandlerConfig {
    skipForward: number;
    skipBackward: number;
}

export const defaultRemoteEventHandlerConfig = {
    skipForward: 10000,
    skipBackward: 10000
};

export const useRemoteEventHandler = (player: THEOplayer | undefined, config: RemoteEventHandlerConfig = defaultRemoteEventHandlerConfig) => {
    useTVEventHandler((evt: HWEvent) => {
        if (evt && evt.eventKeyAction === 0 && player) {
            if (evt.eventType === 'playpause') {
                if (player.paused) {
                    player.play();
                } else {
                    player.pause();
                }
            } else if (evt.eventType === 'play') {
                player.play();
            } else if (evt.eventType === 'pause') {
                player.pause();
            } else if (evt.eventType === 'skip_forward') {
                player.currentTime += config.skipBackward;
            } else if (evt.eventType === 'skip_backward') {
                player.currentTime -= config.skipBackward;
            }
        }
    });
};
