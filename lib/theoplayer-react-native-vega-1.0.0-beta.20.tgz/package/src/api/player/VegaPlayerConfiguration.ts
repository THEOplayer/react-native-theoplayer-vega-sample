import { PlayerConfiguration } from 'react-native-theoplayer';
import { IMediaControlHandlerAsync } from '@amazon-devices/kepler-media-controls';

export interface VegaPlayerConfiguration extends PlayerConfiguration{
    /**
     * Handles media control callback from a remote control.
     */
    mediaControlHandler?: IMediaControlHandlerAsync;
}
