import { TimeRange } from 'react-native-theoplayer';

export function logTimeRanges(ranges: TimeRange[] | undefined): string {
    if (!ranges) {
        return '[]';
    }
    let l = '[';
    for (let i = 0; i < ranges.length; i++) {
        l += `${fmtTimeInSec(ranges[i].start)} - ${fmtTimeInSec(ranges[i].end)}${i < ranges.length - 1 ? ', ' : ''}`;
    }
    l += ']';
    return l;
}

function fmtTimeInSec(msec: number): string {
    return `${(1e-3 * msec).toFixed(2)}`;
}
