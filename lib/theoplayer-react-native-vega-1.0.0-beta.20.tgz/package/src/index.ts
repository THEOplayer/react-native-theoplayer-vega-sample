// remove once this package is part of react-native-theoplayer
export * from 'react-native-theoplayer/src/api/barrel';

export * from './api/barrel';
export { ContentProtectionRegistry } from './internal/drm/ContentProtectionRegistry';
export { sdkVersions } from './internal/version/Version';
