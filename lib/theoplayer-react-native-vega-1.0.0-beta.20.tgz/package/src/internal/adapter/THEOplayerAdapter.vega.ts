import { VideoPlayer } from '@amazon-devices/react-native-w3cmedia';
import { IMediaControlHandlerAsync } from '@amazon-devices/kepler-media-controls';
import pkg from '../../../package.json';

import {
    ABRConfiguration,
    AdsAPI,
    AspectRatio,
    BackgroundAudioConfiguration,
    CastAPI,
    Event,
    EventBroadcastAPI,
    MediaTrack,
    MediaTrackEventType,
    MediaTrackType,
    NativeHandleType,
    PiPConfiguration,
    PlayerEventType,
    PlayerVersion, PreloadType,
    PresentationMode,
    RenderingTarget,
    SeekedEvent,
    SeekingEvent,
    SourceDescription,
    TextTrack,
    TextTrackEventType,
    TextTrackStyle,
    TheoAdsAPI,
    TheoLiveAPI,
    THEOplayer as ReactNativeTHEOplayer,
    TimeRange,
    TrackListEventType,
    PlayerEventMap
} from 'react-native-theoplayer';
import {
    findCoreQualitiesByUid,
    fromCoreCue,
    fromCoreMediaTrack,
    fromCoreTextTrack,
    fromNativeMediaTrackList
} from '../utils/TrackUtils';
import {
    MediaTrack as CoreMediaTrack,
    MediaTrackEventMap as CoreMediaTrackEventMap,
    TextTrack as CoreTextTrack,
    TextTrackEventMap as CoreTextTrackEventMap,
    TrackListEventMap as CoreTrackListEventMap,
    VegaPlayer,
    VegaPlayerEventMap as NativeVegaPlayerEventMap,
    SourceDescription as NativeSourceDescription,
    PreloadType as NativePreloadType,
} from '@theoplayer/vega';
import { IComponentInstance } from '@amazon-devices/react-native-kepler';
import { BaseEvent } from './event/BaseEvent';
import { DefaultEventDispatcher } from './event/DefaultEventDispatcher';
import { DummyCastAPI } from './cast/DummyCastAPI';
import { DummyEventBroadcastAPI } from './broadcast/EventBroadcastAPI';
import { VegaPlayerConfiguration } from '../../api/player/VegaPlayerConfiguration';
import { PromiseController } from '../utils/PromiseController';
import { AdsAPIWrapper } from './ads/AdsAPIWrapper';
import { VegaTheoAdsAPI } from './theoads/VegaTheoAdsAPI';
import { VegaTheoLiveAPI } from './theolive/VegaTheoLiveAPI';
import {
    DefaultDurationChangeEvent,
    DefaultErrorEvent,
    DefaultLoadedMetadataEvent,
    DefaultMediaTrackEvent,
    DefaultMediaTrackListEvent, DefaultProgressEvent, DefaultRateChangeEvent, DefaultReadyStateChangeEvent, DefaultSegmentNotFoundEvent,
    DefaultTextTrackEvent,
    DefaultTextTrackListEvent, DefaultTimeupdateEvent, DefaultVolumeChangeEvent
} from './event/PlayerEvents';
import { TextTrackState, DefaultTextTrackState } from './DefaultTextTrackState';
import { LogixIMAWrapper } from '@logituit/logix-ads-manager';

const defaultBackgroundAudioConfiguration: BackgroundAudioConfiguration = {
    enabled: false
};

const defaultPipConfiguration: PiPConfiguration = {
    startsAutomatically: false
};

class DefaultSeekingEvent extends BaseEvent<PlayerEventType.SEEKING> implements SeekingEvent {
    constructor(public readonly currentTime: number) {
        super(PlayerEventType.SEEKING);
    }
}

class DefaultSeekedEvent extends BaseEvent<PlayerEventType.SEEKED> implements SeekedEvent {
    constructor(public readonly currentTime: number) {
        super(PlayerEventType.SEEKED);
    }
}

const FORWARDED_PLAYER_EVENTS: (keyof NativeVegaPlayerEventMap)[] = [
    'sourcechange',
    'loadstart',
    'loadeddata',
    'loadedmetadata',
    'error',
    'progress',
    'canplay',
    'play',
    'playing',
    'pause',
    'seeking',
    'seeked',
    'ended',
    'waiting',
    'readystatechange',
    'timeupdate',
    'durationchange',
    'ratechange',
    'segmentnotfound',
    'volumechange',
    'dimensionchange',
    'resize'
];

const FORWARDED_TRACKLIST_EVENTS = [
    'addtrack',
    'removetrack',
    'change'
] as const;

const FORWARDED_MEDIATRACK_EVENTS = [
    'activequalitychanged'
] as const;

const FORWARDED_TEXTTRACK_EVENTS = [
    'addcue',
    'removecue',
    'entercue',
    'exitcue'
] as const;

export enum VegaPlayerEventType {
    /**
     * Dispatched when the video element has changed.
     */
    SURFACE_CHANGED = 'surfacechanged'
}

export interface VegaPlayerEventMap extends PlayerEventMap {
    [VegaPlayerEventType.SURFACE_CHANGED]: Event<VegaPlayerEventType.SURFACE_CHANGED>;
}

const LOG_TAG = 'ReactNativeVegaPlayer';

const DEINIT_TIMEOUT_MS = 1500;

interface PlayerState {
    autoplay: boolean;
    volume: number;
    playbackRate: number;
    surfaceHandle: string | undefined;
    captionViewHandle: string | undefined;
}

/**
 * THEOplayerAdapter implements the THEOplayer interface from @theoplayer/react-native.
 *
 * A `nativeHandle` property is provided to expose a web-like player interface for attaching native web connectors.
 */
export class THEOplayerAdapter extends DefaultEventDispatcher<VegaPlayerEventMap> implements ReactNativeTHEOplayer {
    private _player: VegaPlayer | undefined;
    private readonly _cast: CastAPI = new DummyCastAPI();
    private readonly _broadcast: EventBroadcastAPI = new DummyEventBroadcastAPI();
    private _adsAdapter!: AdsAPIWrapper;
    private _theoAdsAdapter!: TheoAdsAPI;
    private _theoLiveAdapter!: TheoLiveAPI;
    private readonly _configuration: VegaPlayerConfiguration | undefined;
    private _video: VideoPlayer;
    private _resetPromise: PromiseController<void> | undefined;
    private readonly _textTrackListeners = new Map<number, (e: CoreTextTrackEventMap[keyof CoreTextTrackEventMap]) => void>();
    private readonly _mediaTrackListeners = new Map<number, (e: CoreMediaTrackEventMap[keyof CoreMediaTrackEventMap]) => void>();
    private _targetVideoQuality: number | number[] | undefined;

    private _surfaceHandle: string | undefined;
    private _captionViewHandle: string | undefined;
    private _mediaControlComponent: IComponentInstance | undefined;
    private _mediaControlHandler: IMediaControlHandlerAsync | undefined;
    private readonly _textTrackState: TextTrackState;

    // Unused property.
    renderingTarget?: RenderingTarget | undefined;

    static async create(configuration?: VegaPlayerConfiguration | undefined): Promise<THEOplayerAdapter> {
        const video = new VideoPlayer();
        await video.initialize();
        return new THEOplayerAdapter(video, configuration);
    }

    constructor(video: VideoPlayer, configuration?: VegaPlayerConfiguration | undefined) {
        super();
        this._configuration = configuration;
        this._video = video;
        this._textTrackState = new DefaultTextTrackState(this);
        this.initPlayer();
    }

    setSurfaceHandle(handle: string | undefined) {
        this._surfaceHandle = handle;
        if (handle) {
            this._video.setSurfaceHandle(handle);
        }
    }

    setCaptionViewHandle(handle: string | undefined) {
        this._captionViewHandle = handle;
        if (handle) {
            this._video.setCaptionViewHandle(handle);
        }
    }

    clearSurfaceHandle(handle: string) {
        this._surfaceHandle = undefined;
        this._video.clearSurfaceHandle(handle);
    }

    clearCaptionViewHandle(handle: string) {
        this._captionViewHandle = undefined;
        this._video.clearCaptionViewHandle(handle);
    }

    async setMediaControlFocus(mediaControlComponent?: IComponentInstance, mediaControlHandler?: IMediaControlHandlerAsync) {
        this._mediaControlComponent = mediaControlComponent;
        this._mediaControlHandler = mediaControlHandler;
        if (mediaControlComponent) {
            await this._video.setMediaControlFocus(mediaControlComponent, mediaControlHandler);
        }
    }

    setAdsManager(adsWrapper: LogixIMAWrapper | null) {
        this._adsAdapter.logixAdsWrapper = adsWrapper;
    }

    private initPlayer() {
        this._player = new VegaPlayer(this._video, this._configuration);
        this._player.addEventListener(FORWARDED_PLAYER_EVENTS, this.forwardCorePlayerEvent_);
        this._player.textTracks.addEventListener(FORWARDED_TRACKLIST_EVENTS, this.forwardCoreTextTrackListEvent_);
        this._player.audioTracks.addEventListener(FORWARDED_TRACKLIST_EVENTS, this.forwardCoreAudioTrackListEvent_);
        this._player.videoTracks.addEventListener(FORWARDED_TRACKLIST_EVENTS, this.forwardCoreVideoTrackListEvent_);
        this._adsAdapter = new AdsAPIWrapper(this._player, this, this._configuration);
        this._theoAdsAdapter = new VegaTheoAdsAPI(this._player);
        this._theoLiveAdapter = new VegaTheoLiveAPI(this._player);
    }

    async destroy() {
        this.clearCaptionViewHandle('');
        this.clearSurfaceHandle('');

        // All Amazon examples use the sync deinitialize version.

        const status = this._video.deinitializeSync(DEINIT_TIMEOUT_MS);
        if (status !== 'success') {
            console.warn(`Failed to deinitialize video element: ${status}`);
        }
        this._adsAdapter.destroy();
        this._player?.destroy();
        this._player = undefined;
    }

    private async resetPlayer() {
        if (this._resetPromise) {
            await this._resetPromise.promise_;
        }
        this._resetPromise = new PromiseController();
        const oldPlayerState: PlayerState = {
            autoplay: this.autoplay,
            volume: this.volume,
            playbackRate: this.playbackRate,
            surfaceHandle: this._surfaceHandle,
            captionViewHandle: this._captionViewHandle
        }
        await this.destroy();
        this._video = new VideoPlayer();
        await this._video.initialize();
        this.initPlayer();

        // Re-attach surface & captionView to any existing Surface
        this.setSurfaceHandle(oldPlayerState.surfaceHandle);
        this.setCaptionViewHandle(oldPlayerState.captionViewHandle);

        // Restore player state
        this.autoplay = oldPlayerState.autoplay;
        this.volume = oldPlayerState.volume;
        this.playbackRate = oldPlayerState.playbackRate;

        // Re-attach mediaControl
        await this.setMediaControlFocus(this._mediaControlComponent, this._mediaControlHandler);

        this.dispatchEvent(new BaseEvent<VegaPlayerEventType.SURFACE_CHANGED>(VegaPlayerEventType.SURFACE_CHANGED));
        this._resetPromise.resolve_();
    }

    get nativeHandle(): NativeHandleType {
        return this._player;
    }

    get version(): PlayerVersion {
        return {
            version: pkg.version,
            playerSuiteVersion: ''
        };
    }

    get aspectRatio(): AspectRatio {
        // TODO:
        return AspectRatio.FIT;
    }

    get keepScreenOn(): boolean {
        return false;
    }

    get pipConfiguration(): PiPConfiguration {
        return defaultPipConfiguration;
    }

    get backgroundAudioConfiguration(): BackgroundAudioConfiguration {
        return defaultBackgroundAudioConfiguration;
    }

    get source(): SourceDescription | undefined {
        return this._player?.source as SourceDescription | undefined;
    }

    set source(source: SourceDescription | undefined) {
        // Vega's video element does not allow setting a new source, so recreate the player first.
        if (this._player?.source !== undefined) {
            this.resetPlayer().then(() => {
                if (this._player) {
                    this._player.source = source as NativeSourceDescription;
                }
            });
        } else {
            if (this._player) {
                this._player.source = source as NativeSourceDescription;
            }
        }
    }

    get presentationMode(): PresentationMode {
        return PresentationMode.inline;
    }

    get textTrackStyle(): TextTrackStyle {
        return this._player?.textTrackStyle as unknown as TextTrackStyle;
    }

    get broadcast(): EventBroadcastAPI {
        return this._broadcast;
    }

    get ads(): AdsAPI {
        return this._adsAdapter;
    }

    get theoads(): TheoAdsAPI {
        return this._theoAdsAdapter;
    }

    get theoLive(): TheoLiveAPI {
        return this._theoLiveAdapter;
    }

    get theolive(): TheoLiveAPI {
        return this._theoLiveAdapter;
    }

    get cast(): CastAPI {
        return this._cast;
    }

    get buffered(): TimeRange[] {
        if (!this._player) {
            return [];
        }
        const nativeRange = this._player.buffered;
        return [...Array(nativeRange.length)].map((_, index) => ({
            start: 1e3 * nativeRange.start(index),
            end: 1e3 * nativeRange.end(index)
        }));
    }

    get currentTime(): number {
        return this._player ? 1e3 * this._player.currentTime : NaN;
    }

    set currentTime(time: number) {
        if (isNaN(time)) {
            return;
        }
        if (this._player) {
            this._player.currentTime = 1e-3 * time;
        }
    }

    get currentProgramDateTime(): number | undefined {
        return this._player?.currentProgramDateTime?.getTime();
    }

    get duration(): number {
        return this._player ? this._player.duration * 1e3 : NaN;
    }

    get muted(): boolean {
        return this._player?.muted ?? false;
    }

    set muted(value: boolean) {
        if (this._player) {
            this._player.muted = value;
        }
    }

    get paused(): boolean {
        return this._player?.paused ?? true;
    }

    get playbackRate(): number {
        return this._player?.playbackRate ?? 1;
    }

    set playbackRate(value: number) {
        const newPlaybackRate = Number(value);
        if (newPlaybackRate < 0) {
            console.error(LOG_TAG, 'playbackRate must be a positive number', value);
            return;
        }
        if (this._player) {
            this._player.playbackRate = newPlaybackRate;
        }
    }

    get preload(): PreloadType {
        return this._player?.preload ?? 'none';
    }

    set preload(value: PreloadType) {
        if (this._player) {
            this._player.preload = value as NativePreloadType;
        }
    }

    get seekable(): TimeRange[] {
        if (!this._player) {
            return [];
        }
        const nativeRange = this._player.seekable;
        return [...Array(nativeRange.length)].map((_, index) => ({
            start: 1e3 * nativeRange.start(index),
            end: 1e3 * nativeRange.end(index)
        }));
    }

    get seeking(): boolean {
        return this._player?.seeking ?? false;
    }

    get volume(): number {
        return this._player?.volume ?? 1;
    }

    set volume(value: number) {
        if (this._player) {
            this._player.volume = value;
        }
    }

    get audioTracks(): MediaTrack[] {
        return this._player ? fromNativeMediaTrackList(this._player.audioTracks) : [];
    }

    get videoTracks(): MediaTrack[] {
        return this._player ? fromNativeMediaTrackList(this._player.videoTracks) : [];
    }

    get textTracks(): TextTrack[] {
        return this._textTrackState.textTracks;
    }

    play(): void {
        this._player?.play();
    }

    get width(): number {
        // TODO
        return 0;
    }

    get height(): number {
        // TODO
        return 0;
    }

    get videoWidth(): number | undefined {
        return this._player?.videoWidth;
    }

    get videoHeight(): number | undefined {
        return this._player?.videoHeight;
    }

    get autoplay() {
        return this._player?.autoplay ?? false;
    }

    set autoplay(value: boolean) {
        if (this._player) {
            this._player.autoplay = value;
        }
    }

    pause(): void {
        this._player?.pause();
    }

    get abr(): ABRConfiguration | undefined {
        return this._player?.abr as ABRConfiguration | undefined;
    }

    get selectedTextTrack(): number | undefined {
        return this._player ? this._textTrackState.selectedTextTrack : undefined;
    }

    set selectedTextTrack(uid: number | undefined) {
        this._textTrackState.selectedTextTrack = uid;

        // Apply native selection
        this._player?.textTracks.forEach((textTrack: CoreTextTrack) => {
            if (textTrack.uid === uid) {
                textTrack.mode = 'showing';
            } else if (textTrack.mode === 'showing') {
                textTrack.mode = 'disabled';
            }
        });
    }

    get selectedAudioTrack(): number | undefined {
        return this._player?.audioTracks.find((audioTrack: CoreMediaTrack) => {
            return audioTrack.enabled;
        })?.uid;
    }

    set selectedAudioTrack(selectedAudioTrack: number | undefined) {
        this._player?.audioTracks.forEach((audioTrack: CoreMediaTrack) => {
            audioTrack.enabled = audioTrack.uid === selectedAudioTrack;
        });
    }

    get selectedVideoTrack(): number | undefined {
        return this._player?.videoTracks.find((videoTrack: CoreMediaTrack) => videoTrack.enabled)?.uid;
    }

    set selectedVideoTrack(selectedVideoTrack: number | undefined) {
        this._targetVideoQuality = undefined;
        this._player?.videoTracks.forEach((videoTrack: CoreMediaTrack) => {
            videoTrack.enabled = videoTrack.uid === selectedVideoTrack;
        });
    }

    get targetVideoQuality(): number | number[] | undefined {
        return this._targetVideoQuality;
    }

    set targetVideoQuality(targetVideoQuality: number | number[] | undefined) {
        const enabledVideoTrack = this._player?.videoTracks.find((videoTrack: CoreMediaTrack) => videoTrack.enabled);
        if (enabledVideoTrack) {
            enabledVideoTrack.targetQuality = findCoreQualitiesByUid(enabledVideoTrack, targetVideoQuality);
        }
        this._targetVideoQuality = targetVideoQuality;
    }

    private forwardCoreTextTrackListEvent_ = <K extends keyof CoreTrackListEventMap>(event: CoreTrackListEventMap[K]): void => {
        const track = event.track as CoreTextTrack;
        switch (event.type) {
            case 'addtrack':
                this.dispatchEvent(new DefaultTextTrackListEvent(TrackListEventType.ADD_TRACK, fromCoreTextTrack(track)));
                track.addEventListener(FORWARDED_TEXTTRACK_EVENTS, this.forwardCoreTextTrackEvent_(track));
                break;
            case 'removetrack':
                this.dispatchEvent(new DefaultTextTrackListEvent(TrackListEventType.REMOVE_TRACK, fromCoreTextTrack(track)));
                track.removeEventListener(FORWARDED_TEXTTRACK_EVENTS, this.forwardCoreTextTrackEvent_(track));
                this._textTrackListeners.delete(track.uid);
                break;
            case 'change':
                this.dispatchEvent(new DefaultTextTrackListEvent(TrackListEventType.CHANGE_TRACK, fromCoreTextTrack(track)));
                break;
        }
    };

    private forwardCoreTextTrackEvent_(track: CoreTextTrack) {
        let listener = this._textTrackListeners.get(track.uid);
        if (!listener) {
            listener = <K extends keyof CoreTextTrackEventMap>(event: CoreTextTrackEventMap[K]) => {
                switch (event.type) {
                    case 'addcue':
                    case 'removecue':
                    case 'entercue':
                    case 'exitcue':
                        this.dispatchEvent(new DefaultTextTrackEvent(event.type as TextTrackEventType, track.uid, fromCoreCue(event.cue)));
                        break;
                }
            };
            this._textTrackListeners.set(track.uid, listener);
        }
        return listener;
    }

    private forwardCoreAudioTrackListEvent_ = <K extends keyof CoreTrackListEventMap>(event: CoreTrackListEventMap[K]): void => {
        this.forwardCoreMediaTrackListEvent_(event.type, MediaTrackType.AUDIO, event.track as CoreMediaTrack);
    };

    private forwardCoreVideoTrackListEvent_ = <K extends keyof CoreTrackListEventMap>(event: CoreTrackListEventMap[K]): void => {
        this.forwardCoreMediaTrackListEvent_(event.type, MediaTrackType.VIDEO, event.track as CoreMediaTrack);
    };

    private forwardCoreMediaTrackListEvent_ = (type: string, trackType: MediaTrackType, track: CoreMediaTrack): void => {
        const mediaTrack = fromCoreMediaTrack(track as CoreMediaTrack);
        switch (type) {
            case 'addtrack':
                this.dispatchEvent(new DefaultMediaTrackListEvent(TrackListEventType.ADD_TRACK, trackType, mediaTrack));
                track.addEventListener(FORWARDED_MEDIATRACK_EVENTS, this.forwardCoreMediaTrackEvent_(trackType, track));
                break;
            case 'removetrack':
                this.dispatchEvent(new DefaultMediaTrackListEvent(TrackListEventType.REMOVE_TRACK, trackType, mediaTrack));
                track.removeEventListener(FORWARDED_MEDIATRACK_EVENTS, this.forwardCoreMediaTrackEvent_(trackType, track));
                this._mediaTrackListeners.delete(track.uid);
                break;
            case 'change':
                this.dispatchEvent(new DefaultMediaTrackListEvent(TrackListEventType.CHANGE_TRACK, trackType, mediaTrack));
                break;
        }
    };

    private forwardCoreMediaTrackEvent_(trackType: MediaTrackType, track: CoreMediaTrack) {
        let listener = this._mediaTrackListeners.get(track.uid);
        if (!listener) {
            listener = <K extends keyof CoreMediaTrackEventMap>(event: CoreMediaTrackEventMap[K]) => {
                switch (event.type) {
                    case 'activequalitychanged':
                        this.dispatchEvent(new DefaultMediaTrackEvent(
                            event.type as MediaTrackEventType,
                            trackType === MediaTrackType.AUDIO ? MediaTrackType.AUDIO : MediaTrackType.VIDEO,
                            track.uid
                        ));
                        break;
                }
            };
            this._mediaTrackListeners.set(track.uid, listener);
        }
        return listener;
    }

    private forwardCorePlayerEvent_ = <K extends keyof NativeVegaPlayerEventMap>(event: NativeVegaPlayerEventMap[K]): void => {
        switch (event.type) {
            case 'error':
                this.dispatchEvent(
                    new DefaultErrorEvent({
                        errorCode: event.errorObject.code.toString(),
                        errorMessage: event.errorObject.message
                    })
                );
                break;
            case 'canplay':
                this.dispatchEvent(new BaseEvent(PlayerEventType.CANPLAY));
                break;
            case 'loadeddata':
                this.dispatchEvent(new BaseEvent(PlayerEventType.LOADED_DATA));
                break;
            case 'loadedmetadata':
                this.dispatchEvent(
                    new DefaultLoadedMetadataEvent(
                        this.textTracks,
                        this.audioTracks,
                        this.videoTracks,
                        this.duration,
                        this.textTracks.find((track) => track.mode === 'showing')?.uid,
                        this._player?.videoTracks.find((track) => track.enabled)?.uid,
                        this._player?.audioTracks.find((track) => track.enabled)?.uid
                    )
                );
                break;
            case 'readystatechange':
                this.dispatchEvent(new DefaultReadyStateChangeEvent(event.readyState));
                break;
            case 'waiting':
                this.dispatchEvent(new BaseEvent(PlayerEventType.WAITING));
                break;
            case 'playing':
                this.dispatchEvent(new BaseEvent(PlayerEventType.PLAYING));
                break;
            case 'durationchange':
                this.dispatchEvent(new DefaultDurationChangeEvent(event.duration * 1e3));
                break;
            case 'ended':
                this.dispatchEvent(new BaseEvent(PlayerEventType.ENDED));
                break;
            case 'loadstart':
                this.dispatchEvent(new BaseEvent(PlayerEventType.LOAD_START));
                break;
            case 'play':
                this.dispatchEvent(new BaseEvent(PlayerEventType.PLAY));
                break;
            case 'progress':
                this.dispatchEvent(new DefaultProgressEvent(this.seekable, this.buffered));
                break;
            case 'pause':
                this.dispatchEvent(new BaseEvent(PlayerEventType.PAUSE));
                break;
            case 'ratechange':
                this.dispatchEvent(new DefaultRateChangeEvent(event.playbackRate));
                break;
            case 'seeking':
                this.dispatchEvent(new DefaultSeekingEvent(event.currentTime * 1e3));
                break;
            case 'seeked':
                this.dispatchEvent(new DefaultSeekedEvent(event.currentTime * 1e3));
                break;
            case 'timeupdate':
                this.dispatchEvent(new DefaultTimeupdateEvent(event.currentTime * 1e3, event.currentProgramDateTime?.getTime()));
                break;
            case 'volumechange':
                this.dispatchEvent(new DefaultVolumeChangeEvent(event.volume, this.muted));
                break;
            case 'segmentnotfound':
                this.dispatchEvent(new DefaultSegmentNotFoundEvent(0, 'Segment not found', -1));
                break;
            case 'sourcechange':
                this.dispatchEvent(new BaseEvent(PlayerEventType.SOURCE_CHANGE));
                break;

            // TODO: review these events, which are not dispatch through react-native-theoplayer
            case 'canplaythrough':
            case 'contentprotectionerror':
            case 'contentprotectionsuccess':
            case 'emptied':
            case 'manifestupdate':
            case 'resize':
            case 'representationchange':
                /* ignore */
                break;
        }
    };
}
