import { AdsContainer, LogixIMAWrapper } from '@logituit/logix-ads-manager';
import React, { useEffect } from 'react';
import { PlayerEventType } from 'react-native-theoplayer';
import { THEOplayer } from '../../../api/THEOplayer';
import { extractAdTagUrl } from './LogixAdsAdapter';
import { DefaultErrorEvent } from '../event/PlayerEvents';

export interface AdsManagerProps {
    player: THEOplayer | undefined;
}

export const LogixAdsContainer = (props: AdsManagerProps) => {
    const logixAdsManager = React.useRef<LogixIMAWrapper | null>(null);
    const [firstPlay, setFirstPlay] = React.useState(false);
    const [adTagUrl, setAdTagUrl] = React.useState<string | undefined>(undefined);

    useEffect(() => {
        const onPlay = () => setFirstPlay(true);
        const onSourceChange = () => {
            const source = props.player?.source;
            if (source?.ads && source.ads.length > 0) {
                // Logix can only handle one ad tag URL, so take first ad.
                const firstAd = source.ads[0];
                const extractedAdTagUrl = extractAdTagUrl(firstAd.sources);
                logixAdsManager.current = null;
                setFirstPlay(false);
                setAdTagUrl(extractedAdTagUrl);
            }
        }

        props.player?.addEventListener(PlayerEventType.PLAY, onPlay);
        props.player?.addEventListener(PlayerEventType.SOURCE_CHANGE, onSourceChange);

        return () => {
            props.player?.removeEventListener(PlayerEventType.PLAY, onPlay);
            props.player?.removeEventListener(PlayerEventType.SOURCE_CHANGE, onSourceChange);
            props.player?.setAdsManager(null);
        }
    }, [props]);

    if (!props.player) {
        return null;
    }

    /**
     * LogixAdsContainer needs an ad tag URL to load the ads manager.
     */
    if (!adTagUrl) {
        return null;
    }

    /**
     * LogixAdsContainer starts play-out once mounted, so hold off on rendering it until the first play event is fired.
     */
    if (!firstPlay) {
        return null;
    }

    return <AdsContainer
        ref={logixAdsManager}
        adTagUrl={adTagUrl}
        onError={(event) => {
            props.player?.dispatchEvent(new DefaultErrorEvent({
                errorCode: `${event.getError().getErrorCode()}`,
                errorMessage: event.getError().getMessage(),
            }));
        }}
        onManagerLoaded={() => {
            if (logixAdsManager && props.player?.ads) {
                props.player.setAdsManager(logixAdsManager.current);
            }
        }}
    />;
};
