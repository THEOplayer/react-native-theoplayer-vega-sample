import { EventBroadcastAPI } from 'react-native-theoplayer';
import type { Event } from 'react-native-theoplayer';

const TAG = 'EventBroadcastAPI';

export class DummyEventBroadcastAPI implements EventBroadcastAPI {
    broadcastEvent(_event: Event) {
        console.warn(TAG, 'Not implemented: EventBroadcastAPI.broadcastEvent');
    }
}
