import { CastAPI } from 'react-native-theoplayer';

export class DummyCastAPI implements CastAPI {
    casting = false;
}
