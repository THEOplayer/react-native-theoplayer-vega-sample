import type { Event } from '@theoplayer/react-native-vega';

export class BaseEvent<TType extends string = string> implements Event<TType> {
  constructor(
    readonly type: TType,
    readonly date: Date = new Date(),
  ) {}
}
