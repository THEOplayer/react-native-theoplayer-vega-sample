import { TheoAdsAPI, Interstitial } from 'react-native-theoplayer';
import { VegaPlayer } from '@theoplayer/vega';

export class VegaTheoAdsAPI implements TheoAdsAPI {
    private readonly _player: VegaPlayer;

    constructor(private readonly player: VegaPlayer) {
        this._player = player;
    }

    get currentInterstitials(): Promise<readonly Interstitial[]> {
        return Promise.resolve([]);
    }

    get scheduledInterstitials(): Promise<readonly Interstitial[]> {
        return Promise.resolve([]);
    }

    replaceAdTagParameters(adTagParameters?: Record<string, string>): void {
        // NYI
    }
}
