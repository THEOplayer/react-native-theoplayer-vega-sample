import { HespLatencies, TheoLiveAPI } from 'react-native-theoplayer';
import { VegaPlayer } from '@theoplayer/vega';

export class VegaTheoLiveAPI implements TheoLiveAPI {
    constructor(private readonly _player: VegaPlayer) {
    }

    /**
     * The latency measured for the playing THEOlive channel
     */
    get currentLatency() {
        return Promise.resolve(0);
    }

    /**
     * A set of latency metrics, measured at different parts of the HESP pipeline.
     */
    get latencies(): Promise<HespLatencies> {
        return Promise.resolve({});
    }

    /**
     * The authentication token used when requesting THEOlive manifests or segments.
     */
    get authToken() {
        return undefined;
    }
}
