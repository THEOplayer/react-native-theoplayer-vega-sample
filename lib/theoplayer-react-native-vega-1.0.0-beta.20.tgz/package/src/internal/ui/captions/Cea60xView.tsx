import React from 'react';
import { View, Text, StyleSheet, StyleProp, TextStyle } from 'react-native';
import { TextTrackCue } from 'react-native-theoplayer';

const CEA608_ROWS = 15;
const CEA608_COLUMNS = 32;
const DEFAULT_FONTSIZE = 36;

interface Cea608ContentWindow {
    characters_: string;
    style_: {
        fontColor_: string;
        fontFamily_: string;
        fontSize_: string;
        backgroundColor_: string;
        windowColor_: string;
        edgeStyle_: string;
    };
    topLeft_: {
        row_: number;
        column_: number;
    }
}

interface Cea608RowProps {
    contentWindow: Cea608ContentWindow;
    captionStyle?: StyleProp<TextStyle>;
}

export const Cea608Row = (props: Cea608RowProps) => {
    const { contentWindow, captionStyle } = props;
    const {
        characters_,
        style_: {
            fontColor_,
            fontFamily_,
            fontSize_,
            backgroundColor_,
            windowColor_,
            edgeStyle_,
        },
        topLeft_: { row_, column_ }
    } = contentWindow;

    const topPct = (row_ / CEA608_ROWS) * 100;
    const leftPct = (column_ / CEA608_COLUMNS) * 100;
    const percent = parseInt(fontSize_ || '100', 10) || 100;
    const baseFontSize = (captionStyle as TextStyle)?.fontSize ?? DEFAULT_FONTSIZE;
    const fontSize = (percent / 100) * baseFontSize;

    const textStyle = {
        color: fontColor_,
        fontFamily: fontFamily_,
        fontSize,
    };

    let containerBg = 'transparent';
    if (windowColor_ && windowColor_ !== 'transparent') {
        containerBg = windowColor_;
    } else if (backgroundColor_ && backgroundColor_ !== 'transparent') {
        containerBg = backgroundColor_;
    }

    const shadow =
        edgeStyle_ && edgeStyle_ !== 'none'
            ? {
                textShadowColor: '#000',
                textShadowOffset: { width: 1, height: 1 },
                textShadowRadius: 1
            }
            : null;

    return (
        <View style={[{position: 'absolute', top: `${topPct}%`, left: `${leftPct}%`, backgroundColor: containerBg }]}>
            <Text style={[textStyle, shadow]}>{characters_}</Text>
        </View>
    );
};

export interface Cea608ViewProps {
    cue: TextTrackCue;
    captionStyle?: StyleProp<TextStyle>;
}

export const Cea608View = (props: Cea608ViewProps) => {
    const { cue, captionStyle } = props;
    return <View style={[styles.root]}>
        {Array.isArray(cue.content) ? cue.content.map(
            (row: Cea608ContentWindow, index: number) => <Cea608Row key={index} captionStyle={captionStyle} contentWindow={row}/>) : null}
    </View>;
};

const styles = StyleSheet.create({
    root: {
        ...StyleSheet.absoluteFillObject,
    }
});
