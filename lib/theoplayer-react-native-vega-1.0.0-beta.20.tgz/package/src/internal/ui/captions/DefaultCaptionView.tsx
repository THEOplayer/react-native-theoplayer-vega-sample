import React from 'react';
import { StyleProp, TextStyle, Text } from 'react-native';
import { TextTrackCue } from 'react-native-theoplayer';

export interface DefaultCaptionViewProps {
    cue: TextTrackCue;
    captionStyle?: StyleProp<TextStyle>;
}

const DEFAULT_CAPTION_STYLE = {
    color: 'white',
    textAlign: 'center',
    backgroundColor: 'transparent',
    fontSize: 36
} as TextStyle;

export const DefaultCaptionView = (props: DefaultCaptionViewProps) => {
    const {cue, captionStyle} = props;
    // Only render cues with text content.
    if (typeof cue.content === 'string') {
        return <Text style={[DEFAULT_CAPTION_STYLE, captionStyle]}>{cue.content}</Text>;
    }
    return null;
}
