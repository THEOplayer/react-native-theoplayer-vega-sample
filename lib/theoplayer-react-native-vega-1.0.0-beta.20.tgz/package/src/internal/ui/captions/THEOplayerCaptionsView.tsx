import { type StyleProp, StyleSheet, type TextStyle, View, type ViewStyle } from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import {
    findTextTrackByUid,
    PlayerEventType,
    TextTrack,
    TextTrackCue,
    TextTrackEvent,
    TextTrackEventType,
    TextTrackType,
    THEOplayer
} from 'react-native-theoplayer';
import { Cea608View } from './Cea60xView';
import { DefaultCaptionView } from './DefaultCaptionView';

const WINDOW_PADDING = '10%';

export interface PlayerCaptionsViewProps {
    player: THEOplayer | undefined;
    style?: StyleProp<ViewStyle>;
    captionStyle?: StyleProp<TextStyle>;
}

const renderCaption = (cue: TextTrackCue, trackType: TextTrackType | undefined, captionStyle?: StyleProp<TextStyle>): React.JSX.Element => {
    switch (trackType) {
        case TextTrackType.cea608:
            return <Cea608View cue={cue} captionStyle={captionStyle}/>;
        default:
            return <DefaultCaptionView cue={cue} captionStyle={captionStyle}/>;
    }
};

export const THEOplayerCaptionsView = ({ style, captionStyle, player }: PlayerCaptionsViewProps) => {
    const [activeCues, setActiveCues] = useState<TextTrackCue[]>([]);
    const trackType = useRef<TextTrackType>(undefined);

    useEffect(() => {
        const onTextTrackEvent = (event: TextTrackEvent) => {
            // Only handle events for the currently selected text track .
            if (player?.selectedTextTrack !== event.trackUid) {
                return;
            }
            const track = findTextTrackByUid(player?.textTracks || [], event.trackUid);
            // Only handle caption or subtitle tracks.
            if (!canDisplay(track)) {
                return;
            }
            trackType.current = track?.type;
            switch (event.subType) {
                case TextTrackEventType.ENTER_CUE:
                    setActiveCues((cues) => addActiveCue(cues, event.cue));
                    break;
                case TextTrackEventType.EXIT_CUE:
                    setActiveCues((cues) => removeActiveCue(cues, event.cue));
                    break;
            }
        };

        const onReset = () => {
            setActiveCues([]);
        };

        player?.addEventListener(PlayerEventType.TEXT_TRACK, onTextTrackEvent);
        player?.addEventListener(PlayerEventType.SOURCE_CHANGE, onReset);

        return () => {
            setActiveCues([]);
            player?.removeEventListener(PlayerEventType.TEXT_TRACK, onTextTrackEvent);
            player?.removeEventListener(PlayerEventType.SOURCE_CHANGE, onReset);
        };
    }, [player]);

    return <View style={[styles.container, style]}>
        {activeCues.map((cue) => renderCaption(cue, trackType.current, captionStyle))}
    </View>;
};

function canDisplay(textTrack?: TextTrack): boolean {
    return textTrack?.kind === 'captions' || textTrack?.kind === 'subtitles';
}

function hasActiveCue(activeCues: TextTrackCue[], cue: TextTrackCue | undefined): boolean {
    return getActiveCue(activeCues, cue) !== undefined;
}

function getActiveCue(activeCues: TextTrackCue[], cue: TextTrackCue | undefined): TextTrackCue | undefined {
    return cue ? activeCues.find((c) => c.uid === cue.uid) : undefined;
}

function addActiveCue(activeCues: TextTrackCue[], cue: TextTrackCue | undefined) {
    return cue && !hasActiveCue(activeCues, cue) ? [...activeCues, cue] : activeCues;
}

function removeActiveCue(activeCues: TextTrackCue[], cue: TextTrackCue | undefined) {
    return cue ? activeCues.filter((c) => c.uid !== cue.uid) : activeCues;
}

const styles = StyleSheet.create({
    container: {
        position: 'absolute',
        left: WINDOW_PADDING,
        right: WINDOW_PADDING,
        top: WINDOW_PADDING,
        bottom: WINDOW_PADDING,
        pointerEvents: 'none',
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'column',
    },
    caption: {
        color: 'white',
        textAlign: 'left',
        backgroundColor: '#000000',
        fontSize: 36
    }
});
