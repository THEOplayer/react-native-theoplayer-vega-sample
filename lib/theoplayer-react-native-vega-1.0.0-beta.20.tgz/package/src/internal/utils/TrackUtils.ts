import type {
    DateRangeCue as CoreDateRangeCue,
    MediaTrack as CoreMediaTrack,
    MediaTrackList as CoreMediaTrackList,
    Quality as CoreQuality,
    TextTrack as CoreTextTrack,
    TextTrackCue as CoreTextTrackCue,
    TextTracksList as CoreTextTrackList
} from '@theoplayer/vega';
import type { MediaTrack, TextTrack, TextTrackCue, DateRangeCue } from 'react-native-theoplayer';

const NAN_VALUE = -1;
const POS_INF_VALUE = -2;

export function decodeNanInf(v: number | undefined) {
    if (v === NAN_VALUE) {
        return NaN;
    }
    if (v === POS_INF_VALUE) {
        return Infinity;
    }
    return v;
}

export function isDateRangeCue(cue: TextTrackCue): cue is DateRangeCue {
    return (cue as CoreDateRangeCue).customAttributes !== undefined;
}

export function fromCoreCue(cue: CoreTextTrackCue): TextTrackCue {
    return {
        id: cue.id,
        uid: cue.uid,
        startTime: decodeNanInf(1e3 * cue.startTime),
        endTime: decodeNanInf(1e3 * cue.endTime),
        content: cue.content,
        ...(isDateRangeCue(cue) && {
            class: cue.class,
            startDate: cue.startDate,
            endDate: cue.endDate,
            duration: cue.duration ? decodeNanInf(1e3 * cue.duration) : cue.duration,
            plannedDuration: cue.plannedDuration ? decodeNanInf(1e3 * cue.plannedDuration) : cue.plannedDuration,
            endOnNext: cue.endOnNext,
            scte35Cmd: cue.scte35Cmd,
            scte35Out: cue.scte35Out,
            scte35In: cue.scte35In,
            customAttributes: cue.customAttributes
        })
    } as TextTrackCue;
}

export function fromCoreTextTrackList(tracks: CoreTextTrackList): TextTrack[] {
    return tracks.map((track) => fromCoreTextTrack(track));
}

export function fromCoreTextTrack(track: CoreTextTrack): TextTrack {
    const { id, uid, kind, label, language, mode, type, src, forced } = track;

    return {
        id,
        uid,
        kind,
        label,
        language,
        mode,
        type,
        src,
        forced,
        cues: track.cues ? track.cues.map((cue) => fromCoreCue(cue)) : []
    } as TextTrack;
}

export function fromNativeMediaTrackList(tracks: CoreMediaTrackList): MediaTrack[] {
    return tracks.map((track) => fromCoreMediaTrack(track));
}

export function fromCoreMediaTrack(track: CoreMediaTrack): MediaTrack {
    const { id, uid, kind, label, language, activeQuality, qualities, enabled } = track;
    return {
        kind,
        label,
        language,
        id,
        uid,
        activeQuality,
        qualities,
        enabled
    } as MediaTrack;
}

export function findCoreQualityByUid(mediaTrack: CoreMediaTrack, uid: number | undefined): CoreQuality | undefined {
    return mediaTrack.qualities.find((quality) => quality.uid === uid);
}

export function findCoreQualitiesByUid(mediaTrack: CoreMediaTrack | undefined, uid: number | number[] | undefined): CoreQuality[] | undefined {
    if (uid !== undefined && mediaTrack) {
        if (Array.isArray(uid)) {
            return mediaTrack.qualities.filter((quality) => uid.includes(quality.uid));
        } else {
            const quality = findCoreQualityByUid(mediaTrack, uid);
            return quality ? [quality] : undefined;
        }
    }
    return undefined;
}
