import type { SdkVersions } from 'react-native-theoplayer';
import { version as nativeVersionString } from '@theoplayer/vega';
import manifest from '../../manifest.json';

export const sdkVersions = async (): Promise<SdkVersions> => {
    const rnVersionString = manifest.version ?? 'NA';
    return {
        rn: rnVersionString,
        native: nativeVersionString
    };
};
