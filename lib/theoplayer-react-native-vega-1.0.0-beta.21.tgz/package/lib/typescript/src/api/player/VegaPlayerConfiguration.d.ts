import { PlayerConfiguration } from 'react-native-theoplayer';
import { IMediaControlHandlerAsync } from '@amazon-devices/kepler-media-controls';
export declare enum VegaFeatures {
    LOGIX_IMA_ADS = "logix_ima_ads"
}
export interface VegaPlayerConfiguration extends PlayerConfiguration {
    /**
     * Handles media control callback from a remote control.
     */
    mediaControlHandler?: IMediaControlHandlerAsync;
    /**
     * Optional features to enable on the THEOplayer.
     */
    features?: VegaFeatures[];
}
//# sourceMappingURL=VegaPlayerConfiguration.d.ts.map