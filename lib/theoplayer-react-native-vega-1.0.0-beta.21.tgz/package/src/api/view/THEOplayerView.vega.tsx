import { StyleSheet, View } from 'react-native';
import { KeplerCaptionsView, KeplerVideoSurfaceView } from '@amazon-devices/react-native-w3cmedia';
import React, { useEffect, useRef, useState } from 'react';
import { THEOplayerViewProps } from 'react-native-theoplayer';
import { THEOplayer } from '../THEOplayer';
import { IKeplerAppStateManager, useKeplerAppStateManager } from '@amazon-devices/react-native-kepler';
import { VegaFeatures, VegaPlayerConfiguration } from '../player/VegaPlayerConfiguration';
import { THEOplayerCaptionsView } from '../../internal/ui/captions/THEOplayerCaptionsView';
import { LogixAdsContainer } from '../../internal/adapter/ads/LogixAdsContainer';

const USE_VEGA_CAPTIONSVIEW = false;

export interface VegaTHEOplayerViewProps extends THEOplayerViewProps {
    /**
     * Whether to reset the player when unmounting the THEOplayerView.
     *
     * @default true, unless a player was provided via props.
     */
    resetPlayerOnUnmount?: boolean;

    /**
     * Optionally provide a headless player that is attached to the THEOplayerView component.
     */
    player?: THEOplayer;

    /**
     * Player configuration.
     */
    config?: VegaPlayerConfiguration;
}

export function THEOplayerView(props: React.PropsWithChildren<VegaTHEOplayerViewProps>) {
    const [vegaPlayer, setVegaPlayer] = useState<THEOplayer | undefined>(props.player);
    const surfaceHandle = useRef<string | undefined>(undefined);
    const captionsViewHandle = useRef<string | undefined>(undefined);
    const keplerAppStateManager: IKeplerAppStateManager = useKeplerAppStateManager();
    const { config, onPlayerReady, player: providedPlayer } = props;

    useEffect(() => {
        console.log('THEOplayerView - ctr');

        // Create an internal player if none was provided.
        if (!providedPlayer) {
            void createPlayer();
        }
    }, []);

    useEffect(() => {
        // Notify the player is ready
        if (vegaPlayer) {
            onPlayerReady?.(vegaPlayer);
        }

        // Clean-up
        return () => {
            // Notify the player will be destroyed.
            const { resetPlayerOnUnmount = (providedPlayer === undefined), onPlayerDestroy } = props;
            if (resetPlayerOnUnmount && vegaPlayer) {
                console.log('THEOplayerView - onPlayerDestroy');
                onPlayerDestroy?.(vegaPlayer);
                void vegaPlayer.destroy();
            }
        };
    }, [vegaPlayer]);

    const createPlayer = async () => {
        console.log('THEOplayerView - createPlayer');
        const newVegaPlayer = await THEOplayer.create(config);
        await newVegaPlayer.setMediaControlFocus(keplerAppStateManager.getComponentInstance(), config?.mediaControlHandler);
        setVegaPlayer(newVegaPlayer);
    };

    const attachSurface = (handle?: string) => {
        surfaceHandle.current = handle;
        if (handle && vegaPlayer) {
            console.log(`THEOplayerView - attachSurface ${handle}`);
            vegaPlayer?.setSurfaceHandle(handle);
        }
    };

    const detachSurface = (handle?: string) => {
        surfaceHandle.current = undefined;
        if (vegaPlayer) {
            console.log(`THEOplayerView - detachSurface ${handle}`);
            vegaPlayer?.clearSurfaceHandle('');
        }
    };

    const attachCaptionsView = (handle?: string) => {
        captionsViewHandle.current = handle;
        if (vegaPlayer) {
            console.log(`THEOplayerView - attachCaptionsView ${handle}`);
            vegaPlayer?.setCaptionViewHandle('');
        }
    };

    const detachCaptionsView = (handle?: string) => {
        captionsViewHandle.current = undefined;
        if (vegaPlayer) {
            console.log(`THEOplayerView - attachCaptionsView ${handle}`);
            vegaPlayer?.clearCaptionViewHandle('');
        }
    };

    useEffect(() => {
        console.log(`THEOplayerView - vegaPlayer changed ${vegaPlayer}`);
        if (vegaPlayer) {
            attachSurface(surfaceHandle.current);
        }
    }, [vegaPlayer]);

    return (
        <View style={[{ flex: 1 }, props.style]}>
            <KeplerVideoSurfaceView style={styles.video} onSurfaceViewCreated={attachSurface} onSurfaceViewDestroyed={detachSurface} />
            {config?.features?.includes(VegaFeatures.LOGIX_IMA_ADS) && <LogixAdsContainer player={vegaPlayer} />}

            {USE_VEGA_CAPTIONSVIEW && (
                <KeplerCaptionsView onCaptionViewCreated={attachCaptionsView} onCaptionViewDestroyed={detachCaptionsView} style={styles.captions} />
            )}
            {!USE_VEGA_CAPTIONSVIEW && <THEOplayerCaptionsView player={vegaPlayer} />}
            {props.children}
        </View>
    );
}

const styles = StyleSheet.create({
    fullscreen: {
        position: 'absolute',
        width: '100%',
        height: '100%'
    },
    video: {
        zIndex: 0
    },
    captions: {
        width: '100%',
        height: '100%',
        top: 0,
        left: 0,
        position: 'absolute',
        backgroundColor: 'transparent',
        flexDirection: 'column',
        alignItems: 'center',
        zIndex: 2
    }
});
