import { Ad, AdBreak, AdDescription, AdsAPI, PlayerEventType, type StringKeyOf } from 'react-native-theoplayer';
import { VegaPlayer, VolumeChangeEvent } from '@theoplayer/vega';
import { DefaultEventDispatcher } from '../event/DefaultEventDispatcher';
import {
    AdErrorEvent as LogixAdErrorEvent,
    AdErrorEventType as LogixAdErrorEventType,
    AdEvent as LogixAdEvent,
    AdEventType as LogixAdEventType,
    LogixIMAWrapper
} from '@logituit/logix-ads-manager';
import { AdEventType } from '@theoplayer/react-native-vega';
import { DefaultAdEvent, DefaultErrorEvent } from '../event/PlayerEvents';
import { adBreakFromCuePoints, extractAdTagUrl, fromLogixAd, INVALID_AD, INVALID_ADBREAK } from './LogixAdsAdapter';
import { VegaPlayerConfiguration } from '../../../api/player/VegaPlayerConfiguration';
import { VegaPlayerEventMap } from '../THEOplayerAdapter.vega';

const DEFAULT_RENDER_SETTINGS = {
    enablePreloading: true,
    uiElements: ['countdown', 'adAttribution'],
    autoAlign: true,
    bitrate: -1,
    loadVideoTimeout: -1,
    mimeTypes: [],
    playAdsAfterTime: 0,
    restoreCustomPlaybackStateOnAdBreakComplete: false
};

export class AdsAPIWrapper implements AdsAPI {
    private _logixAdsWrapper?: LogixIMAWrapper | null = null;
    private _eventIds: (string | undefined)[] = [];
    private _isPlayingAd: boolean = false;
    private _currentAd: Ad | undefined = undefined;
    private _currentAdBreak: AdBreak | undefined = undefined;

    constructor(
        private _player: VegaPlayer,
        private _dispatcher: DefaultEventDispatcher<VegaPlayerEventMap>,
        private _config: VegaPlayerConfiguration | undefined
    ) {
        this.addPlayerEventListeners();
    }

    private addPlayerEventListeners() {
        this._player.addEventListener(PlayerEventType.PLAY, this.onPlayerPlay);
        this._player.addEventListener(PlayerEventType.PAUSE, this.onPlayerPause);
        this._player.addEventListener(PlayerEventType.TIME_UPDATE, this.onPlayerTimeUpdate);
        this._player.addEventListener(PlayerEventType.VOLUME_CHANGE, this.onVolumeChange);
    }

    private removePlayerEventListeners() {
        this._player.removeEventListener(PlayerEventType.PLAY, this.onPlayerPlay);
        this._player.removeEventListener(PlayerEventType.PAUSE, this.onPlayerPause);
        this._player.removeEventListener(PlayerEventType.TIME_UPDATE, this.onPlayerTimeUpdate);
        this._player.removeEventListener(PlayerEventType.VOLUME_CHANGE, this.onVolumeChange);
    }

    private onPlayerPlay = () => {
        // Logix AdManager cannot detect when play is dispatched through the remote buttons.
        // If the player play event is fired while an ad is playing, pause the player to prevent content from playing in the background.
        if (this._isPlayingAd) {
            this._player.pause();
            this?._logixAdsWrapper?.adsManager.resume();
        }
    }

    private onPlayerPause = () => {
        if (this._isPlayingAd) {
            this?._logixAdsWrapper?.adsManager.pause();
        }
    }

    private onPlayerTimeUpdate = () => {
        this?._logixAdsWrapper?.setProgress(this._player.currentTime, this._player.duration);
    }

    private onVolumeChange = (event: VolumeChangeEvent) => {
        if (this._isPlayingAd) {
            this?._logixAdsWrapper?.adsManager.setVolume(event.volume);
        }
    }

    playing() {
        return Promise.resolve(this._isPlayingAd);
    }

    skip() {
        this._logixAdsWrapper?.adsManager.skip();
    }

    currentAdBreak(): Promise<AdBreak> {
        return Promise.resolve(this._currentAdBreak ?? INVALID_ADBREAK);
    }

    currentAds() {
        if (this._currentAd) {
            return Promise.resolve([this._currentAd]);
        }
        return Promise.resolve([]);
    }

    scheduledAdBreaks() {
        // Not supported through Logix.
        return Promise.resolve([]);
    }

    schedule(_ad: AdDescription) {
        // Not supported through Logix.
    }

    destroy() {
        this.removePlayerEventListeners();
        this.removeLogixEventListeners();
    }

    set logixAdsWrapper(logixAdManager: LogixIMAWrapper | null) {
        this._isPlayingAd = false;
        this._logixAdsWrapper = logixAdManager;
        const adsConfig = this._config?.ads;
        if (this._logixAdsWrapper) {
            // Set IMA RenderingSettings
            void this._logixAdsWrapper.adsManager.updateAdsRenderingSettings({
                ...DEFAULT_RENDER_SETTINGS,
                mimeTypes: adsConfig?.allowedMimeTypes ?? [],
                uiElements: (adsConfig?.uiEnabled === false ? [] : ['countdown', 'adAttribution'])
            });
        }
        this.addLogixEventListeners();
    }

    private addLogixEventListeners() {
        this.removeLogixEventListeners();
        if (!this._logixAdsWrapper) {
            return;
        }
        const manager = this._logixAdsWrapper.adsManager;
        this._eventIds.push(manager.addEventListener(LogixAdErrorEventType.AD_ERROR, this.onAddError));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.LOADED, this.onLoaded));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.AD_METADATA, this.onAdMetadata));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.STARTED, this.onStarted));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.COMPLETE, this.onComplete));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.CONTENT_PAUSE_REQUESTED, this.onContentPauseRequested));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.CONTENT_RESUME_REQUESTED, this.onContentResumeRequested));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.AD_PROGRESS, this.onAdProgress));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.FIRST_QUARTILE, this.onFirstQuartile));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.MIDPOINT, this.onMidpoint));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.THIRD_QUARTILE, this.onThirdQuartile));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.AD_BUFFERING, this.onBuffering));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.SKIPPED, this.onSkipped));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.IMPRESSION, this.onImpression));
        this._eventIds.push(manager.addEventListener(LogixAdEventType.CLICK, this.onClicked));
    }

    private removeLogixEventListeners() {
        this._eventIds.forEach(id => {
            if (id) {
                this._logixAdsWrapper?.adsManager.removeEventListener(id);
            }
        });
        this._eventIds = [];
    }

    private onAddError = (data: LogixAdErrorEvent) => {
        this.forwardEvent(new DefaultErrorEvent({
                errorCode: "10000",
                errorMessage: data.getError().getMessage()
        }));
    };

    private onLoaded = (event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_LOADED,
            fromLogixAd(event)
        ));
    };

    private onAdMetadata = (event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_METADATA,
            fromLogixAd(event)
        ));
    };

    /**
     * Dispatched when the ad starts playing.
     */
    private onStarted = (event: LogixAdEvent) => {
        this._currentAd = fromLogixAd(event);
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_BEGIN,
            fromLogixAd(event)
        ));
    };

    /**
     * Dispatched when the ad completes playing.
     */
    private onComplete = (event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_END,
            fromLogixAd(event)
        ));
        this._currentAd = undefined;
    };

    private onContentPauseRequested = async (_event: LogixAdEvent) => {
        this._player.pause();
        this._isPlayingAd = true;
        this._currentAd = undefined;
        const result = await this._logixAdsWrapper?.adsManager.getCuePoints();
        this._currentAdBreak = result ? adBreakFromCuePoints(result.cuePoints) : INVALID_ADBREAK;
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_BREAK_BEGIN,
            this._currentAdBreak ?? INVALID_ADBREAK
        ));
    };

    private onContentResumeRequested = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_BREAK_END,
            this._currentAdBreak ?? INVALID_ADBREAK
        ));
        this._currentAd = undefined;
        this._currentAdBreak = undefined;
        this._isPlayingAd = false;
        this._player.play();
    };

    private onAdProgress = (_event: LogixAdEvent) => {
        // this._logixAdManager?.adsManager.getRemainingTime().then((time) => {
        //     console.log('VegaAds: remainingtime', time);
        // });
    };

    private onFirstQuartile = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_FIRST_QUARTILE,
            fromLogixAd(_event)
        ));
    };

    private onMidpoint = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_MIDPOINT,
            fromLogixAd(_event)
        ));
    };

    private onThirdQuartile = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_THIRD_QUARTILE,
            fromLogixAd(_event)
        ));
    };

    private onBuffering = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_BUFFERING,
            fromLogixAd(_event)
        ));
    };

    private onSkipped = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_SKIP,
            fromLogixAd(_event)
        ));
    };

    private onImpression = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_IMPRESSION,
            fromLogixAd(_event)
        ));
    };

    private onClicked = (_event: LogixAdEvent) => {
        this.forwardEvent(new DefaultAdEvent(
            AdEventType.AD_CLICKED,
            fromLogixAd(_event)
        ));
    };

    private forwardEvent = <K extends StringKeyOf<VegaPlayerEventMap>>(event: VegaPlayerEventMap[K]) => {
        this._dispatcher.dispatchEvent(event);
    }
}
