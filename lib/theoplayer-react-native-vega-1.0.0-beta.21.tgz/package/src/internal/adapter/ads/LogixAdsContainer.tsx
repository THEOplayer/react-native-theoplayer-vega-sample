import { AdsContainer, LogixIMAWrapper } from '@logituit/logix-ads-manager';
import React, { useEffect, useState } from 'react';
import { AdEvent, PlayerEventType } from 'react-native-theoplayer';
import { THEOplayer } from '../../../api/THEOplayer';
import { extractAdTagUrl, INVALID_AD } from './LogixAdsAdapter';
import { DefaultAdEvent } from '../event/PlayerEvents';
import { AdEventType } from 'react-native-theoplayer/src/api/event/AdEvent';
import { StyleSheet, View } from 'react-native';

export interface AdsManagerProps {
    player: THEOplayer | undefined;
}

export const LogixAdsContainer = (props: AdsManagerProps) => {
    const logixAdsManager = React.useRef<LogixIMAWrapper | null>(null);
    const firstPlay = React.useRef<boolean>(false);
    const [isPlayingAds, setIsPlayingAds] = useState(false);
    const [adsContainerKey, setAdsContainerKey] = useState(0);
    const webViewLoaded = React.useRef<boolean>(false);
    const adTagUrl = React.useRef<string | undefined>(undefined);

    const maybeStartAds = () => {
        if (adTagUrl.current && webViewLoaded.current) {
            logixAdsManager.current?.startAdsWith(adTagUrl.current);
        }
    };

    useEffect(() => {
        const onSourceChange = () => {
            firstPlay.current = false;
            setAdsContainerKey(prev => prev + 1); // Increment key to remount AdsContainer
        };

        const onPlay = () => {
            /**
             * If the adTagUrl is passed to the AdsContainer as a property, play-out would start immediately.
             * Instead, pass it once the first play is triggered.
             */
            if (!firstPlay.current) {
                const source = props.player?.source;
                if (source?.ads && source.ads.length > 0) {
                    // Logix can only handle one ad tag URL, so take first ad.
                    adTagUrl.current = extractAdTagUrl(source.ads[0].sources);
                    maybeStartAds();
                }
            }
            firstPlay.current = true;

            // If the source has ads, block play-out until the WebView is loaded
            if (adTagUrl.current && !webViewLoaded.current) {
                props.player?.pause();
            }
        };

        const onAdEvent = (event: AdEvent) => {
            if ([AdEventType.AD_BREAK_BEGIN, AdEventType.AD_BEGIN].includes(event.subType)) {
                setIsPlayingAds(true);
            }
            if ([AdEventType.AD_BREAK_END, AdEventType.AD_SKIP, AdEventType.AD_ERROR].includes(event.subType)) {
                setIsPlayingAds(false);
            }
        };

        props.player?.setAdsManager(logixAdsManager.current);
        props.player?.addEventListener(PlayerEventType.PLAYING, onPlay);
        props.player?.addEventListener(PlayerEventType.SOURCE_CHANGE, onSourceChange);
        props.player?.addEventListener(PlayerEventType.AD_EVENT, onAdEvent);

        return () => {
            props.player?.setAdsManager(null);
            props.player?.removeEventListener(PlayerEventType.PLAYING, onPlay);
            props.player?.removeEventListener(PlayerEventType.SOURCE_CHANGE, onSourceChange);
            props.player?.removeEventListener(PlayerEventType.AD_EVENT, onAdEvent);
            firstPlay.current = false;
        };
    }, [props]);

    useEffect(() => {
        return () => {
            // eslint-disable-next-line react-hooks/exhaustive-deps
            logixAdsManager.current?.destroy();
        };
    }, []);

    if (!props.player) {
        return null;
    }

    return (<View style={isPlayingAds ? styles.adContainer : styles.collapsedAdContainer}>
        <AdsContainer
            key={adsContainerKey}
            ref={logixAdsManager}
            adTagUrl={undefined}
            onError={(event) => {
                console.warn(`Logix Ads Manager error: ${event.getError().getErrorCode()} - ${event.getError().getMessage()}`);
                props.player?.dispatchEvent(new DefaultAdEvent(
                    AdEventType.AD_ERROR,
                    INVALID_AD
                ));
            }}
            onManagerLoaded={() => props.player?.setAdsManager(logixAdsManager.current)}
            onWebViewLoaded={() => {
                webViewLoaded.current = true;
                // Unblock play-out if play was triggered before WebView was loaded
                if (firstPlay?.current) {
                    props.player?.play();
                }
                maybeStartAds();
            }}
        />
    </View>);
};

const styles = StyleSheet.create({
    collapsedAdContainer: {
        height: 0,
        width: 0,
        zIndex: -1,
        overflow: 'hidden'
    },
    adContainer: {
        ...StyleSheet.absoluteFillObject,
        zIndex: 100
    }
});
