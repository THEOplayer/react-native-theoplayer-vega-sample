# THEOplayer Vega

THEOplayer Vega is the universal video player solution for the Amazon Vega platform created by THEO Technologies.

## Prerequisites

- A valid THEOplayer license. Request yours via our [THEOportal](https://portal.theoplayer.com).

## Included features

## Installation

Install using your favorite package manager for Node (such as `npm` or `yarn`):

```bash
npm install @theoplayer/vega
```

You can also install a specific version instead:

```bash
npm install @theoplayer/vega@1.0.0-beta.20
```

## Usage

## Documentation

## Support

If you are having issues installing or using the package, first look for existing answers on our [documentation website](https://www.theoplayer.com/docs/),
and in particular our [FAQ](https://www.theoplayer.com/docs/theoplayer/faq/).

You can also contact our technical support team by following the instructions on our [support page](https://www.theoplayer.com/docs/theoplayer/faq/).
Note that your level of support depends on your selected [support plan](https://www.theoplayer.com/supportplans).

## License

The contents of this package are subject to the [THEOplayer license](https://www.theoplayer.com/terms).
